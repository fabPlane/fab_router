# Single-segment native thermal regression

Exact frozen Aquarius J4 source board, with its MIT license and unchanged native
project/custom rules. Append `added.sexpr` before the board's final close.
The segment comes from placement-corrected engine `8fa7ead0`, seed 1.

Native 10.0.6 refill: source has zero errors and 110 opens; source plus the one
horizontal B.Cu segment has one starved thermal at GNDD U1.39 and 111 opens.
All source-connected terminal pairs remain connected. Removing the segment
restores the source result. Source geometry and authored zone rules are retained.

This is a reduction of the six-error benchmark failure, not a repaired route or
a globally minimized board. `full-added.sexpr.gz` contains all 466 added copper items from the full output,
six thermal errors, 15 opens and 348 lost source-connected terminal pairs.
The original single-track detour generator emits no paths for axial segments.
Complete deletion trials and repeat controls are under the c205 evidence assets.

`axial-input.kicad_pcb.gz` is the same source with only the second and third
occurrences of the duplicated Edge.Cuts graphical UUID replaced deterministically.
This fixture-only identity repair lets the strict proposal identity guard run;
no copper, outline geometry, pads, zones or rules change. The original frozen
input above is retained byte-for-byte. The axial search regression adds the same
signal segment, then restores the thermal and 110-open source budget without
losing either source-connected or routed-connected terminal pairs.

`connectivity-added.sexpr` reduces the separate source-connectivity blocker to
three added B.Cu signal segments (0.2032 mm, on three distinct nets). Together
they isolate GNDD U1.39 from the other 61 pads in its source-connected group after
native refill: one thermal error, 114 opens, 61 lost source pairs. Removing ANY
one of these three segments restores all source pairs (112 opens; thermal
errors vary). The full source geometry/rules remain unchanged; this is a
one-deletion-minimal added-copper witness, not a globally minimized board or a
route repair. The horizontal segment is also the earlier one-track thermal
witness: thermal starvation alone does not imply this terminal partition.
All 74 discovery/refill checks and three-repeat controls are retained in the
c207 evidence assets. No production behavior or scored outcome changes.

`connectivity-detour.sexpr` replaces the first horizontal track with the current
generator's first endpoint-preserving detour. Native 10.0.6 reports zero errors,
112 opens and zero lost source/routed pairs, but reassigns all three detour tracks
from `Net-(C1-Pad1)` to `Net-(R1-Pad1)` on refill. This is an UNSAFE diagnostic,
not a repair. The gate still rejects it because the source budget is 110 opens.
A separate load-only control isolates reassignment to native board loading,
before explicit connectivity build, refill, DRC or save.
The c208 evidence explicitly audits submitted versus native-saved ownership;
report/terminal counts alone must not be interpreted as proof of route fidelity.
