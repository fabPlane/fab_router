import pathlib,sys,gzip,copy,shutil,json
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
F=pathlib.Path('test/fixtures/native-aquarius-thermal');source=sx.parse(gzip.decompress((F/'input.kicad_pcb.gz').read_bytes()).decode());ids={sx.uid(n) for n in source if isinstance(n,list)}
power=sx.parse((R/'baseline.kicad_pcb').read_text());extra=[n for n in power if isinstance(n,list) and n[0] in ['segment','via'] and sx.uid(n) not in ids];assert len(extra)==65
(F/'power-stage0-added.sexpr.gz').write_bytes(gzip.compress(('\n'.join(map(sx.dump,extra))+'\n').encode(),mtime=0))
full=sx.parse((R.parent/'c216/full-port/candidate.kicad_pcb').read_text())
for family,nodes in [('power',power),('full',full)]:
 out=R/family;out.mkdir();candidate=copy.deepcopy(nodes);modified=[]
 for n in candidate:
  if not isinstance(n,list) or n[0] not in ['segment','via'] or sx.uid(n) in ids:continue
  touched=False
  for key in ['at','start','end']:
   point=sx.child(n,key)
   if point and [float(x) for x in point[1:3]]==[164.1045,50.6008]:point[1:3]=['163.804500','50.900800'];touched=True
  if touched:modified.append(sx.uid(n))
 assert len(modified)==4
 (out/'delta.json').write_text(json.dumps(dict(modified=modified,delta=[-.3,.3]),indent=2)+'\n')
 for name,b in [('input',source),('routed',nodes),('candidate',candidate)]:
  (out/(name+'.kicad_pcb')).write_text(sx.dump(b)+'\n')
  for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(F/('board'+ext),out/(name+ext))
