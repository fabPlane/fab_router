import pathlib,sys,json,copy,subprocess,shutil,importlib.util
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
base=sx.parse((R/'full/routed.kicad_pcb').read_text()); source=json.loads((R.parent/'c215/source-groups.json').read_text());rows=[]
for dx,dy in [(0,.4),(0,.5),(0,.6),(.1,.4),(.1,.5),(.1,.6),(.2,.4),(.2,.5),(.2,.6),(-.1,.4),(-.1,.5),(-.2,.4)]:
 name=f'full-via-{dx}-{dy}';out=R/name;out.mkdir();nodes=copy.deepcopy(base);changed=[]
 for n in nodes:
  if not isinstance(n,list) or n[0] not in ['segment','via']:continue
  touched=False
  for key in ['start','end','at']:
   p=sx.child(n,key)
   if p and [float(x) for x in p[1:3]]==[164.1045,50.6008]:p[1:3]=[f'{164.1045+dx:.6f}',f'{50.6008+dy:.6f}'];touched=True
  if touched:changed.append(sx.uid(n))
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(R/('baseline'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'full-probe-results.json').write_text(json.dumps(rows,indent=2)+'\n')
