import pathlib,json,sys,math
import pcbnew
root=pathlib.Path(sys.argv[1]);rows=[]
for name in ['source','before','via-0.1','upper-via-0.1','via-pair-0.1']:
 b=pcbnew.LoadBoard(str(root/name/'board.kicad_pcb'))
 for z in b.Zones():
  if z.GetNetname()=='GNDD' and z.IsOnLayer(pcbnew.B_Cu):
   rows.append(dict(name=name,outlines=z.GetFilledPolysList(pcbnew.B_Cu).OutlineCount(),minThickness=z.GetMinThickness()/1e6))
assert [r['outlines'] for r in rows]==[1,2,2,1,1]
gaps=[]
for delta in [0,.1]:
 distance=math.hypot(164.1045-(162.9939-delta),50.6008-(50.8553+delta))
 gaps.append(dict(shift=delta,centerDistance=distance,nominalCopperGap=distance-.762,nominalClearanceGap=distance-.762-.127*2))
print(json.dumps(dict(topology=rows,viaClearanceEnvelope=gaps,note='Nominal circular via clearance gap only; native topology is authoritative.'),indent=2))
