import pathlib,sys,importlib.util,gzip,subprocess,json,shutil,math
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/home/hyper/bench/wt/fr-bugs'); FIX=REPO/'test/fixtures/native-aquarius-thermal'
sys.path.insert(0,str(ROOT));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',REPO/'tools/native-terminal-groups.py');gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
source=sx.parse(gzip.decompress((FIX/'input.kicad_pcb.gz').read_bytes()).decode()); added=sx.parse('(kicad_pcb '+(FIX/'connectivity-nets.sexpr').read_text()+')')[1:]
rows=[];baseline=None
for name,extras in [('source-outward',[])]+[(f'outward-{d}',added+sx.parse('(kicad_pcb '+ '\n'.join(f'(via (at {x+d/2**.5:.6f} {y-d/2**.5:.6f}) (size 0.5) (drill 0.3) (layers "F.Cu" "B.Cu") (net "GNDD") (uuid "00000000-0000-4000-8000-00000000000{i}"))\n(segment (start {x} {y}) (end {x+d/2**.5:.6f} {y-d/2**.5:.6f}) (width 0.2032) (layer "B.Cu") (net "GNDD") (uuid "00000000-0000-4000-8000-00000000001{i}"))' for i,(x,y) in enumerate([(165.881998,50.182214),(165.174891,49.475107)]))+')')[1:]) for d in [-0.6,-0.8,-1.0]]:
 out=ROOT/name;out.mkdir(exist_ok=False);board=out/'board.kicad_pcb';board.write_text(sx.dump(source+extras)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups)); membership={v:i for i,g in enumerate(groups) for v in g}
 if baseline is None:baseline=groups
 report=json.loads((out/'drc.json').read_text());r=dict(name=name,opens=len(report['unconnected_items']),errors=[v['type'] for v in report['violations'] if v['severity']=='error'],lost_pairs=sum(membership[a]!=membership[b] for group in baseline for i,a in enumerate(group) for b in group[i+1:]));rows.append(r);print(r,flush=True);(ROOT/'outward-results.json').write_text(json.dumps(rows,indent=2))
