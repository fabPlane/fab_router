import {nativeCopperPreserved,assertSourceCopper,assertSourcePads,assertBoardZones,assertEmbeddedBoardRules,assertBoardNets} from '/home/hyper/bench/wt/fr-bugs/tools/kicad-board-rules.ts';
import {readFile,writeFile} from 'node:fs/promises';const r=process.argv[2]!;
const submitted=await readFile(r+'/recheck-normalized/candidate.kicad_pcb','utf8'),saved=await readFile(r+'/independent/board.kicad_pcb','utf8'),source=await readFile(r+'/recheck-normalized/input.kicad_pcb','utf8');
if(!nativeCopperPreserved(submitted,saved))throw Error('Native copper changed');
for(const assert of [assertSourceCopper,assertSourcePads,assertBoardZones,assertEmbeddedBoardRules,assertBoardNets]) assert(source,submitted);
await writeFile(r+'/independent-verification.json',JSON.stringify({nativeCopperPreserved:true,sourceFidelity:true},null,2));
