exec(open(__file__.replace('via.py','probe.py')).read().split('rows=[];baseline=None')[0])
import copy
baseline=json.loads((ROOT/'source/groups.json').read_text());rows=[]
for offset in [.05,.10,.20,.30]:
 extras=copy.deepcopy(added);modified=[]
 for n in extras:
  for key in ['at','start','end']:
   point=sx.child(n,key)
   if point and point[1:3]==['163.3455','51.5585']:
    point[2]=str(51.5585+offset);modified.append(sx.uid(n))
 name=f'via-{offset}';out=ROOT/name;out.mkdir();board=out/'board.kicad_pcb';(out/'added.sexpr').write_text('\n'.join(sx.dump(n) for n in extras)+'\n');board.write_text(sx.dump(source+extras)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));membership={v:i for i,g in enumerate(groups) for v in g};report=json.loads((out/'drc.json').read_text());r=dict(name=name,modified=modified,opens=len(report['unconnected_items']),errors=[v['type'] for v in report['violations'] if v['severity']=='error'],lost_pairs=sum(membership[a]!=membership[b] for group in baseline for i,a in enumerate(group) for b in group[i+1:]));rows.append(r);print(r,flush=True);(ROOT/'via-results.json').write_text(json.dumps(rows,indent=2))
