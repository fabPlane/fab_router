"""Independent exact Decimal physical copper and semantic net inventory replay."""
import sys,pathlib,collections,json
from decimal import Decimal,InvalidOperation
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import sexpr as sx
r=pathlib.Path(sys.argv[1])
def inventory(path):
 board=sx.parse(path.read_text());names={'0':'""'}
 for n in board:
  if isinstance(n,list) and n[0]=='net' and len(n)==3:names[n[1]]=n[2]
 def atom(value):
  if isinstance(value,list):return tuple(atom(v) for v in value)
  try:return Decimal(value)
  except InvalidOperation:return value
 result=collections.Counter()
 for n in board:
  if not isinstance(n,list) or n[0] not in ['segment','arc','via']:continue
  nf=sx.child(n,'net');net=nf[1] if nf else '""';net=names.get(net,net)
  assert net.startswith('"'),net
  geometry=[]
  for field in n[1:]:
   if isinstance(field,list) and field[0] in ['start','end','mid','at','width','size','drill','layer','layers']:
    tag='endpoint' if n[0] in ['segment','arc'] and field[0] in ['start','end'] else field[0]
    geometry.append((tag,tuple(atom(v) for v in field[1:])))
  result[(n[0],net,tuple(sorted(geometry,key=repr)))]+=1
 return result
before=inventory(r/'recheck-normalized/input.kicad_pcb');submitted=inventory(r/'recheck-normalized/candidate.kicad_pcb');saved=inventory(r/'independent/board.kicad_pcb')
assert not before-submitted
assert submitted==saved
assert sum((submitted-before).values())==74
print(json.dumps(dict(exactDecimalPhysicalInventory=True,semanticOwnership=True,originalCopperSubset=True,generatedItems=74),indent=2))
