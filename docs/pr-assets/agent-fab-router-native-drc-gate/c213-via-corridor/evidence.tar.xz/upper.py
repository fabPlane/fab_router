exec(open(__file__.replace('upper.py','probe.py')).read().split('rows=[];baseline=None')[0])
import copy
baseline=json.loads((ROOT/'source/groups.json').read_text());rows=[]
target='9dd50fff-11c6-4002-8144-cb40c29da824'
original=next(n for n in added if sx.uid(n)==target);a=list(map(float,sx.child(original,'start')[1:]));b=list(map(float,sx.child(original,'end')[1:]));dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy);ux=dx/length;uy=dy/length
for offset in [-.1,-.06,.06,.10]:
 ramp=.15;points=[a,[a[0]+ux*ramp-uy*offset,a[1]+uy*ramp+ux*offset],[b[0]-ux*ramp-uy*offset,b[1]-uy*ramp+ux*offset],b];replacement=[]
 for i in range(3):
  n=copy.deepcopy(original);sx.child(n,'start')[1:]=[f'{v:.6f}' for v in points[i]];sx.child(n,'end')[1:]=[f'{v:.6f}' for v in points[i+1]];sx.child(n,'uuid')[1]=f'"00000000-0000-4000-8000-00000000002{i}"';replacement.append(n)
 extras=[n for n in added if sx.uid(n)!=target]+replacement
 name=f'upper-{offset}';out=ROOT/name;out.mkdir();board=out/'board.kicad_pcb';(out/'added.sexpr').write_text('\n'.join(sx.dump(n) for n in extras)+'\n');board.write_text(sx.dump(source+extras)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));membership={v:i for i,g in enumerate(groups) for v in g};report=json.loads((out/'drc.json').read_text());r=dict(name=name,opens=len(report['unconnected_items']),errors=[v['type'] for v in report['violations'] if v['severity']=='error'],lost_pairs=sum(membership[a]!=membership[b] for group in baseline for i,a in enumerate(group) for b in group[i+1:]));rows.append(r);print(r,flush=True);(ROOT/'upper-results.json').write_text(json.dumps(rows,indent=2))
