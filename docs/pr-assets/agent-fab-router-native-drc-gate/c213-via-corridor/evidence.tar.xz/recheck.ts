import {checkNativeRepair} from '/home/hyper/bench/wt/fr-bugs/tools/native-drc-gate.ts';
import {mkdir,writeFile,readFile} from 'node:fs/promises';import {gunzipSync} from 'node:zlib';import {join} from 'node:path';
const root=process.argv[2]!, fixture='/home/hyper/bench/wt/fr-bugs/test/fixtures/native-aquarius-thermal';await mkdir(join(root,'recheck'));
const source=gunzipSync(await readFile(join(fixture,'input.kicad_pcb.gz'))).toString();const end=source.lastIndexOf(')');
for(const [name,added] of [['input',''],['routed',await readFile(join(fixture,'connectivity-nets.sexpr'),'utf8')],['candidate',await readFile(join(root,'via-pair-0.1/added.sexpr'),'utf8')]]){
 await writeFile(join(root,'recheck',name+'.kicad_pcb'),source.slice(0,end)+added+'\n'+source.slice(end));
 for(const ext of ['.kicad_pro','.kicad_dru'])await writeFile(join(root,'recheck',name+ext),await readFile(join(fixture,'board'+ext)));
}
const rows=[];for(let repeat=0;repeat<3;repeat++)for(const name of ['routed','candidate']){
 const checked=await checkNativeRepair(join(root,'recheck/input.kicad_pcb'),join(root,'recheck/routed.kicad_pcb'),join(root,'recheck',name+'.kicad_pcb'));
 await writeFile(join(root,'recheck',`${name}-${repeat}.json`),JSON.stringify(checked,null,2));
 const row={name,repeat,errors:checked.newErrors.map(e=>e.type),opens:checked.opensAfter,lostSource:checked.lostTerminalPairs,lostRouted:checked.repair?.lostTerminalPairs,ownership:checked.nativeCopperChecks,accepted:checked.accepted,repairAccepted:checked.repair?.accepted};rows.push(row);console.log(row);
}await writeFile(join(root,'recheck-results.json'),JSON.stringify(rows,null,2));
