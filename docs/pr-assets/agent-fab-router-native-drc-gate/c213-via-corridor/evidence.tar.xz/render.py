import pathlib,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="960"><rect width="1600" height="960" fill="#f6f8fa"/><g font-family="sans-serif" fill="#172b4d"><text x="40" y="55" font-size="34">Reopening the ground-pour corridor without removing routes</text>']
for i,(name,title,label) in enumerate([('before','Before: two complete generated nets','61 lost source pairs; 94 opens; 2 thermals'),('after','After: two vias moved 0.1 mm left/down','0 lost source pairs; 93 opens; 2 thermals')]):
 x=40+i*790;parts.append(f'<text x="{x}" y="110" font-size="25">{title}</text>')
 board=ET.parse(root/(name+'.svg')).getroot();board.set('x',str(x));board.set('y','145');board.set('width','740');board.set('height','640');board.set('viewBox','162.3 49.7 4.6 3.8')
 ET.SubElement(board,'{http://www.w3.org/2000/svg}circle',{'cx':str(162.9939-i*.1),'cy':str(50.8553+i*.1),'r':'.58','fill':'none','stroke':'#e87c16','stroke-width':'.035'})
 parts.append(ET.tostring(board,encoding='unicode'));parts.append(f'<text x="{x}" y="825" font-size="23">{label}</text>')
parts.append('<text x="40" y="890" font-size="24">Orange circle: upper moved TCK via. Source copper, rules, widths and drills preserved.</text><text x="40" y="935" font-size="24">Partial recovery only: native gate still rejects both remaining thermal violations.</text></g></svg>');(root/'comparison.svg').write_text(''.join(parts))
