import pathlib,sys,json,copy,subprocess,shutil,importlib.util,time
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
P=R.parent/'c217'; base=sx.parse((P/'joint-via--0.2-0/submitted.kicad_pcb').read_text());source=json.loads((P/'source-groups.json').read_text());rows=[]
target='526748ae-cdba-488b-9c2f-37172461148a'
for i,(x,y) in enumerate([(163.8045,50.4),(163.8045,50.2),(164.2,50.2),(164.2,50.4),(164.7563,50.9008),(164.4,51.0),(164.7563,51.1),(163.5,50.4),(163.5,50.2)]):
 name=f'detour-{i}';out=R/name;out.mkdir();nodes=copy.deepcopy(base);changed=[target]
 for j,n in enumerate(nodes):
  if isinstance(n,list) and sx.uid(n)==target:
   first=copy.deepcopy(n);second=copy.deepcopy(n)
   sx.child(first,'end')[1:3]=[str(x),str(y)];sx.child(second,'start')[1:3]=[str(x),str(y)]
   sx.child(second,'uuid')[1]=f'"22000000-0000-4000-8000-{i:012d}"'
   nodes[j:j+1]=[first,second];break
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(P/('baseline'+ext),board.with_suffix(ext))
 start=time.monotonic();p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,seconds=time.monotonic()-start,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'detour-results.json').write_text(json.dumps(rows,indent=2)+'\n')
