import pathlib,sys,json,copy,subprocess,shutil,importlib.util,time
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
P=R/'controls'; base=sx.parse((P/'joint-via--0.2-0/submitted.kicad_pcb').read_text());source=json.loads((P/'source-groups.json').read_text());rows=[]
for powerdy,tckdy in [(p,t) for p in [0,-.1,-.2,-.3] for t in [.2,.4,.6,.8]]:
 name=f'corners-{powerdy}-{tckdy}';out=R/name;out.mkdir();nodes=copy.deepcopy(base);changed=[]
 for n in nodes:
  if not isinstance(n,list) or n[0] not in ['segment','via']:continue
  touched=False
  for key in ['start','end','at']:
   pt=sx.child(n,key)
   if not pt:continue
   xy=[float(x) for x in pt[1:3]]
   for old,dy in [([164.7563,50.6008],powerdy),([165.1035,51.5585],tckdy)]:
    if xy==old and dy:pt[1:3]=[f'{xy[0]:.6f}',f'{xy[1]+dy:.6f}'];touched=True
  if touched:changed.append(sx.uid(n))
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(P/('baseline'+ext),board.with_suffix(ext))
 start=time.monotonic();p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,seconds=time.monotonic()-start,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
