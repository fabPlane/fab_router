from pathlib import Path
R=Path(__file__).resolve().parent
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"><rect width="1600" height="900" fill="#f5f7fa"/><g font-family="sans-serif" fill="#172638"><text x="70" y="80" font-size="40">Full-board coordinated via control</text><text x="70" y="125" font-size="24">Manual native geometry experiment • same retained board • three fresh repeats</text>']
for i,(label,thermal,clearance,opens,lost,current) in enumerate([('Before',6,0,13,235,0),('Power via alone',5,3,14,292,57),('Coordinated vias',5,0,13,235,0)]):
 x=70+i*510;s.append(f'<rect x="{x}" y="185" width="470" height="500" rx="18" fill="white" stroke="#ccd5df"/><text x="{x+25}" y="235" font-size="28">{label}</text>')
 for j,(name,value) in enumerate([('Thermal errors',thermal),('Added clearances',clearance),('Opens',opens),('Lost source pairs',lost),('Lost current pairs',current)]):
  y=300+j*72;s.append(f'<text x="{x+25}" y="{y}" font-size="23">{name}</text><text x="{x+420}" y="{y}" text-anchor="end" font-size="30" fill="{chr(35)}b23a35">{value}</text>')
s.append('<text x="70" y="755" font-size="29">All three remain rejected by final source-based acceptance.</text><text x="70" y="805" font-size="24">Coordinated geometry preserves current pairs; five thermal errors and source losses remain.</text><text x="70" y="850" font-size="21">Diagnostic control only. No automatic search or scored routing improvement.</text></g></svg>')
(R/'comparison.svg').write_text(''.join(s))
