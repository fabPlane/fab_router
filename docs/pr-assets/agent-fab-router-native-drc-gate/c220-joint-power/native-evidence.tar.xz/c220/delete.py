import pathlib,sys,json,copy,subprocess,shutil,importlib.util,time
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
P=R.parent/'c217'; base=sx.parse((P/'joint-via--0.2-0/submitted.kicad_pcb').read_text());source=json.loads((P/'source-groups.json').read_text());rows=[]
eligible=[]
for n in base:
 if isinstance(n,list) and n[0]=='segment' and sx.child(n,'layer')[1]=='"B.Cu"':
  a=sx.child(n,'start');b=sx.child(n,'end')
  if min(float(a[1]),float(b[1]))<167 and max(float(a[1]),float(b[1]))>163 and min(float(a[2]),float(b[2]))<53 and max(float(a[2]),float(b[2]))>49:eligible.append(sx.uid(n))
for i,uid in enumerate(eligible):
 name=f'delete-{i}';out=R/name;out.mkdir();nodes=[n for n in copy.deepcopy(base) if not(isinstance(n,list) and sx.uid(n)==uid)];changed=[uid]
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(P/('baseline'+ext),board.with_suffix(ext))
 start=time.monotonic();p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,seconds=time.monotonic()-start,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'deletion-results.json').write_text(json.dumps(rows,indent=2)+'\n')
