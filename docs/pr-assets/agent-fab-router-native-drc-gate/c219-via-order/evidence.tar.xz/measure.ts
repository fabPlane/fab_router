import {resolve,join} from 'node:path';
import {writeFile} from 'node:fs/promises';
const {searchNativeThermals}=await import(resolve('tools/native-thermal-search.ts'));
const root=resolve(process.argv[2]!);const source=resolve(root,'../c218/native/input.kicad_pcb');const routed=resolve(root,'../c218/native/routed.kicad_pcb');
const rows=[];
for(let i=0;i<3;i++){
 const start=performance.now();
 const result=await searchNativeThermals(source,routed,join(root,`accepted-${i}.json`),join(root,`search-${i}`));
 const seconds=(performance.now()-start)/1000;
 if(!result.published||result.attempts.length!==7||result.validation.newErrors.length||result.validation.opensAfter!==95||result.validation.lostTerminalPairs||result.validation.repair?.lostTerminalPairs)throw new Error('Unexpected/unsafe recovery');
 rows.push({repeat:i,seconds,attempts:result.attempts.length,published:result.published,thermals:result.validation.newErrors.length,opens:result.validation.opensAfter,lostSource:result.validation.lostTerminalPairs,lostCurrent:result.validation.repair?.lostTerminalPairs,ownership:result.validation.nativeCopperChecks});
 await writeFile(join(root,'measurement.json'),JSON.stringify(rows,null,2)+'\n');console.log(rows.at(-1));
 if(seconds>=600)throw new Error('Exceeds unchanged adapter cap');
}
