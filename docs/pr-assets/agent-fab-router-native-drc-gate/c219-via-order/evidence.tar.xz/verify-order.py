import pathlib,json,hashlib,subprocess
r=pathlib.Path(__file__).resolve().parent
base=r.parent/'c218/native'
for version,script in [('before',r/'before.py'),('after',pathlib.Path.cwd()/'tools/native-thermal-proposals.py')]:
 subprocess.run(['python3',str(script),'--source',str(base/'input.kicad_pcb'),'--current',str(base/'routed.kicad_pcb'),'--report',str(base/'before-0.json'),'--out',str(r/version)],check=True)
a=json.loads((r/'before/manifest.json').read_text());b=json.loads((r/'after/manifest.json').read_text())
assert len(a)==len(b)==200
assert sorted(a,key=lambda x:x['name'])==sorted(b,key=lambda x:x['name'])
probe=next(row for row in a if row['label'][0]=='via')
assert a.index(probe)==168 and b.index(probe)==6
assert [row for row in a if row!=probe]==[row for row in b if row!=probe]
for row in a: assert (r/'before'/row['name']).read_bytes()==(r/'after'/row['name']).read_bytes()
result={'candidates':len(a),'all_candidate_bytes_identical':True,'all_other_relative_order_identical':True,'via_index_before':168,'via_index_after':6,'probe_sha256':hashlib.sha256((r/'after'/probe['name']).read_bytes()).hexdigest()}
(r/'order-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
