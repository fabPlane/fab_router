from pathlib import Path
import xml.etree.ElementTree as E
r=Path(__file__).resolve().parent
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1040"><rect width="1600" height="1040" fill="#f6f8fa"/><g font-family="sans-serif" fill="#172b4d"><text x="40" y="50" font-size="32">Reach the same safe via repair after seven candidate checks</text>']
for i,name in enumerate(['power-before','power-after']):
 x=40+i*780
 parts.append(f'<text x="{x}" y="100" font-size="24">'+('Before: one U1.55 thermal' if i==0 else 'Via + three endpoints: zero thermal errors')+'</text>')
 s=E.parse(r/(name+'.svg')).getroot();s.set('x',str(x));s.set('y','130');s.set('width','740');s.set('height','690');s.set('viewBox','163.15 48.5 4 3.7')
 E.SubElement(s,'{http://www.w3.org/2000/svg}circle',dict(cx=str(164.1045-i*.3),cy=str(50.6008+i*.3),r='.45',fill='none',stroke='#e87c16',**{'stroke-width':'.035'}))
 E.SubElement(s,'{http://www.w3.org/2000/svg}circle',dict(cx='165.174891',cy='49.475107',r='.28',fill='none',stroke='#35d2a0',**{'stroke-width':'.03'}))
 parts.append(E.tostring(s,encoding='unicode'))
parts.append('<text x="40" y="865" font-size="25">Generated power-net candidate: 95 opens; zero lost source/current pairs.</text><text x="40" y="910" font-size="24">Orange: generated power via moves (-0.3,+0.3) mm. Green: U1.55 ground pad.</text><text x="40" y="960" font-size="23">Same 200 candidate boards; first via probe moves from position 169 to position 7.</text><text x="40" y="1005" font-size="23">Native acceptance required. This partial power-net control is not a scored routing gain.</text></g></svg>')
(r/'comparison.svg').write_text(''.join(parts))
