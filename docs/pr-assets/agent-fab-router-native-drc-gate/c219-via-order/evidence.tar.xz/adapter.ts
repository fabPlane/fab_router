import {resolve,join} from 'node:path';import {mkdir,copyFile,writeFile} from 'node:fs/promises';
const root=resolve(process.argv[2]!);await mkdir(join(root,'adapter-inputs'));
for(const name of ['input','routed'])for(const ext of ['.kicad_pcb','.kicad_pro','.kicad_dru'])await copyFile(join(root,'native',name+ext),join(root,'adapter-inputs',name+ext));
const {postprocess}=await import('/home/hyper/bench/wt/fp-bugs/packages/router/bench/native-thermal-postprocess.ts');
const started=performance.now();const result=await postprocess(join(root,'adapter-inputs/input.kicad_pcb'),join(root,'adapter-inputs/routed.kicad_pcb'),resolve('.'),join(root,'adapter'));
const record={...result,seconds:(performance.now()-started)/1000};await writeFile(join(root,'adapter-measurement.json'),JSON.stringify(record,null,2)+'\n');console.log(record);if(!result.applied||result.searchExitCode!==0||record.seconds>=600)throw Error('Adapter recovery failed');
