import {checkNativeRepair,publishNativeRepair} from '/home/hyper/bench/wt/fr-bugs/tools/native-drc-gate.ts';
import {writeFile,readFile} from 'node:fs/promises';import {join} from 'node:path';
const root=join(import.meta.dir,'backbone');
for(let repeat=1;repeat<3;repeat++)for(const [label,candidate] of [['before','routed'],['after','candidate']]){
const checked=await checkNativeRepair(join(root,'input.kicad_pcb'),join(root,'routed.kicad_pcb'),join(root,candidate+'.kicad_pcb'));
await writeFile(join(root,`${label}-${repeat}.json`),JSON.stringify(checked,null,2)+'\n');
console.log(label,repeat,checked.accepted,checked.opensAfter,checked.newErrors.map(x=>x.type),checked.nativeCopperChecks);
}
const publication=await publishNativeRepair(join(root,'input.kicad_pcb'),join(root,'routed.kicad_pcb'),join(root,'candidate.kicad_pcb'),join(root,'accepted.json'));
if(!publication.published)throw new Error('Expected exact complete-net witness publication');
console.log('published',publication.published);
