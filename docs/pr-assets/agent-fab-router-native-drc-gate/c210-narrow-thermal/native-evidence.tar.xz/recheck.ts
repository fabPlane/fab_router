import {checkNativeRepair} from '/home/hyper/bench/wt/fr-bugs/tools/native-drc-gate.ts';
import {readFile,writeFile} from 'node:fs/promises';import {join} from 'node:path';
const root=import.meta.dir,rows=[];
for(let repeat=0;repeat<3;repeat++){
const checked=await checkNativeRepair(join(root,'input.kicad_pcb'),join(root,'routed.kicad_pcb'),join(root,'r0.06-s1/board.kicad_pcb'));
await writeFile(join(root,`recheck-${repeat}.json`),JSON.stringify(checked,null,2)+'\n');
const row={repeat,accepted:checked.accepted,errors:checked.newErrors.map(x=>x.type),opens:checked.opensAfter,lost:checked.lostTerminalPairs,nativeCopperChecks:checked.nativeCopperChecks};rows.push(row);console.log(row);
}await writeFile(join(root,'recheck-summary.json'),JSON.stringify(rows,null,2)+'\n');
