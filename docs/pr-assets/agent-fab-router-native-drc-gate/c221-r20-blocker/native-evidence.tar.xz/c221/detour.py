import pathlib,sys,json,copy,subprocess,shutil,importlib.util,time
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
P=R.parent/'c220/repeat-0'; base=sx.parse((P/'joint.kicad_pcb').read_text());source=gp.terminal_groups(str(P/'input.kicad_pcb'));rows=[]
eligible=list(dict.fromkeys(n['uid'] for p in json.loads((R/'nearby.json').read_text()) for n in p['near']))
spec2=importlib.util.spec_from_file_location('prop',pathlib.Path('tools/native-thermal-proposals.py'));prop=importlib.util.module_from_spec(spec2);sys.modules['prop']=prop;spec2.loader.exec_module(prop)
uid='fa3f4b5e-8a05-43e8-aacb-933e02c54760'
for i,blob in enumerate(prop.proposals(base,uid)):
 name=f'r20-detour-{i}';out=R/name;out.mkdir();nodes=sx.parse(blob.decode());changed=[uid]
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(P/('input'+ext),board.with_suffix(ext))
 start=time.monotonic();p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,seconds=time.monotonic()-start,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'detour-results.json').write_text(json.dumps(rows,indent=2)+'\n')
