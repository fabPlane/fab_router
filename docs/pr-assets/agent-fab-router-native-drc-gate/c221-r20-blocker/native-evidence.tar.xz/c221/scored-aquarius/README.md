# Subset

3/3 attempts completed; 0 valid.

[Open comparison visualization](report.html) · [Machine-readable results](summary.json)

| Router | Valid runs | Tasks passing 3/3 | Efficient | Fast |
| --- | ---: | ---: | ---: | ---: |
| fab_router | 0/3 | 0/1 | None | None |

Valid cases require 3/3. Efficiency and time scores use medians, only on cases with at least two routers passing 3/3. Close timing differences require matched idle-machine runs.
