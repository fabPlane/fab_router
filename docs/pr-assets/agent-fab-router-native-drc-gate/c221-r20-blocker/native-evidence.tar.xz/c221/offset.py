import pathlib,sys,json,copy,subprocess,shutil,importlib.util,time
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',pathlib.Path('tools/native-terminal-groups.py'));gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
P=R.parent/'c220/repeat-0'; base=sx.parse((P/'joint.kicad_pcb').read_text());source=gp.terminal_groups(str(P/'input.kicad_pcb'));rows=json.loads((R/'offset-results.json').read_text())
eligible=list(dict.fromkeys(n['uid'] for p in json.loads((R/'nearby.json').read_text()) for n in p['near']))
spec2=importlib.util.spec_from_file_location('prop',pathlib.Path('tools/native-thermal-proposals.py'));prop=importlib.util.module_from_spec(spec2);sys.modules['prop']=prop;spec2.loader.exec_module(prop)
uid='fa3f4b5e-8a05-43e8-aacb-933e02c54760'
witness=next(n for n in base if isinstance(n,list) and sx.uid(n)==uid)
pointstart,pointend=[tuple(map(float,sx.child(witness,k)[1:3])) for k in ['start','end']]
for i,(dx,dy) in enumerate([(0,-r) for r in [.15,.3,.45,.6]]+[(r,0) for r in [.15,.3,.45,.6]]+[(0,r) for r in [.15,.3,.45,.6]]+ [(-r,0) for r in [.15,.3,.45,.6]]):
 name=f'r20-offset-{i}';out=R/name;
 if i==0:continue
 out.mkdir(exist_ok=True);nodes=copy.deepcopy(base);nodes.remove(next(n for n in nodes if isinstance(n,list) and sx.uid(n)==uid));changed=[uid]
 points=[pointstart,(pointstart[0]+dx,pointstart[1]+dy),(pointend[0]+dx,pointend[1]+dy),pointend]
 for j,(a,b) in enumerate(zip(points,points[1:])):
  n=copy.deepcopy(witness)
  for k,xy in [('start',a),('end',b)]:sx.child(n,k)[1:3]=[f'{v:.6f}' for v in xy]
  sx.child(n,'uuid')[1]='"'+str(__import__('uuid').uuid5(__import__('uuid').NAMESPACE_URL,f'c221-offset-{i}-{j}'))+'"';nodes.append(n)
 board=out/'board.kicad_pcb';board.write_text(sx.dump(nodes)+'\n');(out/'submitted.kicad_pcb').write_bytes(board.read_bytes())
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(P/('input'+ext),board.with_suffix(ext))
 start=time.monotonic();p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));member={x:i for i,g in enumerate(groups) for x in g};errors=[e for e in d['violations'] if e['severity']=='error'];row=dict(name=name,changed=changed,seconds=time.monotonic()-start,opens=len(d['unconnected_items']),lostSource=sum(member[a]!=member[b] for g in source for i,a in enumerate(g) for b in g[i+1:]),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(row);print(row,flush=True);(R/'offset-results.json').write_text(json.dumps(rows,indent=2)+'\n')
