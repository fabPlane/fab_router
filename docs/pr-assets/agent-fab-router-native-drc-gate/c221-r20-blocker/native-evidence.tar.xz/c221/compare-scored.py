from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;before=R.parent/'c217/full-router';after=R/'scored-aquarius'
b=sorted([x for x in json.load(open(before/'results.json')) if x['case']=='kitspace-aquarius-j4'],key=lambda x:x['seed']);a=sorted(json.load(open(after/'results.json')),key=lambda x:x['seed']);assert len(a)==len(b)==3
keys=['case','router','seed','status','passed','vias','length_mm','opens','new_errors','new_error_types','failed_fidelity']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for old,new in zip(b,a):
 assert all(old[k]==new[k] for k in keys)
 blobs={name:[sha(base/row['evidence']/'work'/name) for base,row in [(before,old),(after,new)]] for name in ['board.dsn','board.ses']}
 assert all(v[0]==v[1] for v in blobs.values())
 assert old['check']['integrity_checks']==new['check']['integrity_checks']
 rows.append(dict(seed=new['seed'],matching_fields=keys,blobs=blobs))
controls=[json.load(open(p/'controls.json')) for p in [before,after]]
matched={k:controls[0][k]==controls[1][k] for k in ['inputs_sha256','configs_sha256','harness_sha256','runtime_sha256','runtime_source_sha256','seeds','allowed_cpus','safety_stop_seconds']};assert all(matched.values())
(R/'scored-before.json').write_text(json.dumps(b,indent=2)+'\n');(R/'scored-before-controls.json').write_text(json.dumps(controls[0],indent=2)+'\n');result=dict(before='retained cycle217 full-router Aquarius rows',after='fresh cycle221 subset',same_controls=matched,pairs=rows,passed_before=0,passed_after=0,opens_before=45,opens_after=45,thermal_errors_before=18,thermal_errors_after=18,verified=True);(R/'scored-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
