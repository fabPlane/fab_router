import pathlib,sys,importlib.util,gzip,subprocess,json,shutil,copy
SCRIPT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else SCRIPT
ROOT.mkdir(parents=True,exist_ok=True)
REPO=pathlib.Path.cwd();FIX=REPO/'test/fixtures/native-aquarius-thermal'
sys.path.insert(0,str(SCRIPT));import sexpr as sx
spec=importlib.util.spec_from_file_location('gp',REPO/'tools/native-terminal-groups.py');gp=importlib.util.module_from_spec(spec);spec.loader.exec_module(gp)
source=sx.parse(gzip.decompress((FIX/'input.kicad_pcb.gz').read_bytes()).decode());full=sx.parse('(kicad_pcb '+gzip.decompress((FIX/'full-added.sexpr.gz').read_bytes()).decode()+')')[1:]
baseline=json.loads((SCRIPT/'source-groups.json').read_text());rows=[]
# Upper TCK via and all incident generated track endpoints move together.
# LED4's two adjacent vias and incident endpoints translate left, preserving connectivity.
for name,delta in [(f'capacitor-detour-{v}',v) for v in [.1,.2,.3,.4]]:
 dx,dy,led=-.1,.1,-.12
 extras=copy.deepcopy(full);modified=[]
 for n in extras:
  touched=False
  for key in ['at','start','end']:
   point=sx.child(n,key)
   if not point:continue
   x,y=point[1:3]
   if [x,y]==['162.9939','50.8553']:
    point[1:3]=[f'{float(x)+dx:.6f}',f'{float(y)+dy:.6f}'];touched=dx!=0 or dy!=0
   elif sx.child(n,'net')[1]=='"/Leds/Stars/LED4"' and x=='162.3543' and y in ['48.764','51.5768']:
    point[1]=f'{float(x)+led:.6f}';touched=led!=0
  if touched:modified.append(sx.uid(n))
 target=next(n for n in extras if sx.uid(n)=='d86e9512-200c-46ad-83c9-170c84138a71');extras.remove(target)
 pts=[(165.815,48.1278),(165.815-delta*2,48.1278),(164.8213,49.1215-delta*2),(164.8213,49.1215)]
 import uuid
 for i,(start,end) in enumerate(zip(pts,pts[1:])):
  n=copy.deepcopy(target);sx.child(n,'start')[1:3]=[f'{v:.6f}' for v in start];sx.child(n,'end')[1:3]=[f'{v:.6f}' for v in end];sx.child(n,'uuid')[1]='"'+str(uuid.uuid5(uuid.NAMESPACE_URL,f'c215-{delta}-{i}'))+'"';extras.append(n)
 modified.append(sx.uid(target))
 out=ROOT/name;out.mkdir();board=out/'board.kicad_pcb';(out/'added.sexpr').write_text('\n'.join(sx.dump(n) for n in extras)+'\n');board.write_text(sx.dump(source+extras)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 groups=gp.terminal_groups(str(board));(out/'groups.json').write_text(json.dumps(groups));membership={v:i for i,g in enumerate(groups) for v in g};report=json.loads((out/'drc.json').read_text());r=dict(name=name,modified=modified,opens=len(report['unconnected_items']),errors=[v['type'] for v in report['violations'] if v['severity']=='error'],lost_pairs=sum(membership[a]!=membership[b] for group in baseline for i,a in enumerate(group) for b in group[i+1:]));rows.append(r);print(r,flush=True);(ROOT/'detour-results.json').write_text(json.dumps(rows,indent=2))
