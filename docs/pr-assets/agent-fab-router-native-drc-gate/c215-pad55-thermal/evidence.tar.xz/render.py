import pathlib,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="960"><rect width="1600" height="960" fill="#f6f8fa"/><g font-family="sans-serif" fill="#172b4d"><text x="40" y="55" font-size="34">Restoring ground connectivity can expose a thermal failure</text>']
for i,(name,title,label) in enumerate([('before','Before: ground corridor already restored','292 lost source pairs; 14 opens; 6 thermals'),('after','After: capacitor via moves up 0.10 mm','235 lost source pairs; 13 opens; 7 thermals')]):
 x=40+i*790;parts.append(f'<text x="{x}" y="110" font-size="25">{title}</text>')
 board=ET.parse(root/(name+'.svg')).getroot();board.set('x',str(x));board.set('y','145');board.set('width','740');board.set('height','640');board.set('viewBox','163.8 47.35 3.2 3.2')
 ET.SubElement(board,'{http://www.w3.org/2000/svg}circle',{'cx':str(165.815),'cy':str(48.1278-i*.1),'r':'.58','fill':'none','stroke':'#e87c16','stroke-width':'.035'})
 parts.append(ET.tostring(board,encoding='unicode'));parts.append(f'<text x="{x}" y="825" font-size="23">{label}</text>')
parts.append('<text x="40" y="890" font-size="24">Orange circle: moved capacitor via. U1.55 gains 57 source pairs but has only one thermal spoke.</text><text x="40" y="935" font-size="24">Both final and relative repair gates reject; no automatic repair or scored improvement.</text></g></svg>');(root/'comparison.svg').write_text(''.join(parts))
