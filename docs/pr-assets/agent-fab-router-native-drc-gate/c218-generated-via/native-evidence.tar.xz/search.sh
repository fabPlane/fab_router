#!/bin/bash
cd /home/hyper/bench/wt/fr-bugs || exit 2
exec taskset -c 20-25 nice -n 10 timeout 3600 bun tools/native-thermal-search.ts /home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c218/native/input.kicad_pcb /home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c218/native/routed.kicad_pcb /home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c218/accepted.json /home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c218/search
