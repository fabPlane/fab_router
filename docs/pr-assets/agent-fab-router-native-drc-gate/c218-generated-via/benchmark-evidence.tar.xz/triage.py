from pathlib import Path
import json,sys
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
results=json.loads((r/'optional-after/results.json').read_text());rows=[]
for case in ['kitspace-aquarius-j4','hellscribe-hellscribe-j2-large','qrpcard-qrpcard-j2-small','qrpcard-qrpcard-j4']:
 selected=[v for v in results if v['case']==case];assert len(selected)==3
 for v in selected:
  work=r/'optional-after'/v['evidence']/'work/native-thermal-postprocess';p=json.loads((work/'postprocess.json').read_text())
  if not (work/'search/result.json').exists():
   reason=(work/'search.stderr.log').read_text().strip()
   assert p['status']=='search-failed' and reason=='Candidate source pads differ from input'
   rows.append(dict(case=case,seed=v['seed'],passed=v['passed'],opens=v['opens'],newErrors=v['new_errors'],postprocessStatus=p['status'],preflightFailure=reason))
   continue
  s=json.loads((work/'search/result.json').read_text());b=json.loads((work/'search/baseline.json').read_text())
  rows.append(dict(case=case,seed=v['seed'],passed=v['passed'],opens=v['opens'],newErrors=v['new_errors'],initialLostSourcePairs=b['lostTerminalPairs'],initialNewErrors=[e['type'] for e in b['newErrors']],stages=s['stages'],attempts=len(s['attempts']),repaired=s['repaired'],published=s['published'],finalLostSourcePairs=s['validation']['lostTerminalPairs'],postprocessStatus=p['status']))
assert all(v['preflightFailure']=='Candidate source pads differ from input' and v['postprocessStatus']=='search-failed' for v in rows if v['case']=='kitspace-aquarius-j4')
assert all(v['initialLostSourcePairs']==17 and not v['published'] for v in rows if v['case']=='hellscribe-hellscribe-j2-large')
assert all(v['finalLostSourcePairs']==0 and v['published'] and v['passed'] for v in rows if v['case'].startswith('qrpcard-'))
print(json.dumps(rows,indent=2))
