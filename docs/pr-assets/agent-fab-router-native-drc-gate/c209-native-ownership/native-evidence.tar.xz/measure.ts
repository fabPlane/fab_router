import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { checkNativeBoards as before } from './before-tools/native-drc-gate.ts';
import { checkNativeBoards as after } from '/home/hyper/bench/wt/fr-bugs/tools/native-drc-gate.ts';
const root=import.meta.dir, fixture='/home/hyper/bench/wt/fr-bugs/test/fixtures/native-saved-copper';
const results=[];
for(const [phase,check] of [['before',before],['after',after]] as const) for(const mode of ['candidate','control']) for(let repeat=0;repeat<3;repeat++) {
 const dir=join(root,'measure',phase,`${mode}-${repeat}`);await mkdir(dir,{recursive:true});
 for(const name of ['input',mode]) {await writeFile(join(dir,`${name}.kicad_pcb`),await readFile(join(fixture,`${name}.kicad_pcb`)));await writeFile(join(dir,`${name}.kicad_pro`),await readFile(join(fixture,'board.kicad_pro')));}
 const validation=await check(join(dir,'input.kicad_pcb'),join(dir,`${mode}.kicad_pcb`));
 await writeFile(join(dir,'validation.json'),JSON.stringify(validation,null,2)+'\n');
 const row={phase,mode,repeat,accepted:validation.accepted,errors:validation.newErrors.length,opens:validation.opensAfter,lostPairs:validation.lostTerminalPairs};results.push(row);console.log(JSON.stringify(row));
 await writeFile(join(root,'measurement.json'),JSON.stringify(results,null,2)+'\n');
}
