/** Conservative comparison of embedded board rules. Separate from the permissive DSN
 * reader: native board strings have backslash escapes and malformed input must fail. */
type Expression = string | Expression[];

function parseBoard(text: string): Expression[] {
  let offset = 0;
  const whitespace = () => { while (offset < text.length && /\s/.test(text[offset]!)) offset++; };
  function expression(depth: number): Expression {
    if (depth > 256) throw new Error("Native board nesting limit exceeded");
    whitespace();
    if (text[offset] === "(") {
      offset++;
      const values: Expression[] = [];
      while (true) {
        whitespace();
        if (offset >= text.length) throw new Error("Unclosed native board expression");
        if (text[offset] === ")") { offset++; return values; }
        values.push(expression(depth + 1));
      }
    }
    const start = offset;
    if (text[offset] === '"') {
      offset++;
      while (offset < text.length) {
        const char = text[offset++];
        if (char === "\\") { offset++; continue; }
        if (char === '"') {
          if (offset < text.length && !/[\s()]/.test(text[offset]!)) throw new Error("Missing native board string separator");
          return text.slice(start, offset);
        }
      }
      throw new Error("Unclosed native board string");
    }
    while (offset < text.length && !/[\s()"]/.test(text[offset]!)) offset++;
    if (start === offset) throw new Error("Malformed native board token");
    const token = text.slice(start, offset);
    // Ignore numeric formatting, but never reinterpret quoted strings as numbers.
    return /^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(token) && Number.isFinite(Number(token)) ? String(Number(token)) : token;
  }
  const board = expression(0);
  whitespace();
  if (offset !== text.length || !Array.isArray(board) || board[0] !== "kicad_pcb") throw new Error("Expected exactly one native board expression");
  return board;
}

export function embeddedBoardRules(text: string): string {
  const board = parseBoard(text);
  return JSON.stringify(["layers", "setup"].map(head => {
    const matches = board.filter(node => Array.isArray(node) && node[0] === head);
    if (matches.length !== 1) throw new Error(`Expected exactly one native board ${head}`);
    const section = matches[0] as Expression[];
    // Native save supplies default display aliases for user layers. These are
    // presentation metadata; retain IDs, canonical names, types and table order.
    return head === "layers" ? [head, ...section.slice(1).map(layer => {
      if (!Array.isArray(layer) || layer.length < 3 || layer.length > 4 || layer.some(value => typeof value !== "string")) throw new Error("Malformed native layer definition");
      return layer.slice(0, 3);
    })] : section;
  }));
}

export function assertEmbeddedBoardRules(input: string, candidate: string): void {
  if (embeddedBoardRules(input) !== embeddedBoardRules(candidate)) throw new Error("Candidate embedded board rules differ from input");
}

/** Numeric net fields only identify electrical ownership through this table. Routing
 * may add copper, but must not add, remove or rename the board's electrical nets. */
export function assertBoardNets(input: string, candidate: string): void {
  const inventory = (text: string) => {
    const nets = new Map<string, string>();
    const names = new Set<string>();
    for (const node of parseBoard(text)) {
      if (!Array.isArray(node) || node[0] !== "net") continue;
      const [_, id, name] = node;
      if (node.length !== 3 || typeof id !== "string" || !/^\d+$/.test(id) || !Number.isSafeInteger(Number(id)) || typeof name !== "string" || !name.startsWith('"') || !name.endsWith('"') || nets.has(id) || names.has(name)) throw new Error("Malformed native net table");
      nets.set(id, name); names.add(name);
    }
    return JSON.stringify([...nets].sort(([a], [b]) => Number(a) - Number(b)));
  };
  if (inventory(input) !== inventory(candidate)) throw new Error("Candidate net table differs from input");
}

/** Preserve the multiset of original board-level tracks and vias. Additional routes
 * are permitted. This deliberately does not certify pads, zones or other metadata. */
export function assertSourceCopper(input: string, candidate: string): void {
  const inventory = (text: string) => {
    const counts = new Map<string, number>();
    for (const node of parseBoard(text)) {
      if (!Array.isArray(node) || !["segment", "arc", "via"].includes(String(node[0]))) continue;
      // Named fields may be reordered by a native save; keep each field's internal
      // order (notably via layer span and arc geometry) intact.
      const fields = node.slice(1).filter(field => !(Array.isArray(field) && field[0] === "uuid"));
      const key = JSON.stringify([node[0], ...fields.map(field => {
        // Tracks and arcs are physically undirected; native save may reverse them.
        if (Array.isArray(field) && ["segment", "arc"].includes(String(node[0])) && ["start", "end"].includes(String(field[0]))) return JSON.stringify(["endpoint", ...field.slice(1)]);
        return JSON.stringify(field);
      }).sort()]);
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return counts;
  };
  const available = inventory(candidate);
  for (const [key, count] of inventory(input)) {
    if ((available.get(key) ?? 0) < count) throw new Error("Candidate source copper differs from input");
  }
}

/** Preserve authored zone definitions, including thermal and keepout rules. Filled
 * polygons/segments are derived refill caches; only those and UUIDs may change. */
export function assertBoardZones(input: string, candidate: string): void {
  const inventory = (text: string) => parseBoard(text)
    .filter(node => Array.isArray(node) && node[0] === "zone")
    .map(node => {
      const zone = node as Expression[];
      // Sort top-level named fields only. Polygon vertex order and nested fill
      // rules remain intact; unknown future fields are protected conservatively.
      return JSON.stringify(zone.slice(1)
        .filter(field => !(Array.isArray(field) && ["uuid", "filled_polygon", "filled_segments"].includes(String(field[0]))))
        .map(field => JSON.stringify(field)).sort());
    }).sort();
  if (JSON.stringify(inventory(input)) !== JSON.stringify(inventory(candidate))) throw new Error("Candidate zone definitions differ from input");
}

/** Preserve source terminals and their footprint-local rule context. Pad coordinates
 * are local: matching pad bytes alone cannot detect a moved/flipped footprint. */
export function assertSourcePads(input: string, candidate: string): void {
  const inventory = (text: string) => {
    const result: string[] = [];
    for (const node of parseBoard(text)) {
      if (!Array.isArray(node) || node[0] !== "footprint") continue;
      const context = node.filter(field => Array.isArray(field) && [
        "at", "layer", "clearance", "solder_mask_margin", "solder_paste_margin",
        "solder_paste_ratio", "zone_connect", "thermal_width", "thermal_gap",
      ].includes(String(field[0]))).map(field => JSON.stringify(field)).sort();
      for (const field of node) {
        if (!Array.isArray(field) || field[0] !== "pad") continue;
        // Only identifier metadata is disposable. Keep pad type/shape, geometry,
        // net, layer set, drill, custom primitives and all local/unknown rules.
        const values = field.slice(1).filter(value => !(Array.isArray(value) && value[0] === "uuid"));
        const atoms = values.filter(value => !Array.isArray(value));
        const fields = values.filter(value => Array.isArray(value)).map(value => JSON.stringify(value)).sort();
        result.push(JSON.stringify([context, atoms, fields]));
      }
    }
    return JSON.stringify(result.sort());
  };
  if (inventory(input) !== inventory(candidate)) throw new Error("Candidate source pads differ from input");
}

/** Compare physical copper and its semantic electrical ownership across native
 * load/save. Legacy numeric codes are local to each board; current files use
 * quoted names. UUIDs and native-added display/manufacturing defaults are outside
 * this check. Multiplicity and exact physical coordinates remain significant. */
export function nativeCopperInventory(text: string): string[] {
  const board = parseBoard(text), nets = new Map<string, string>([["0", '""']]);
  const declared = new Set<string>(), names = new Set<string>();
  const quoted = (value: Expression | undefined): value is string => typeof value === "string" && value.startsWith('"') && value.endsWith('"');
  for (const node of board) {
    if (!Array.isArray(node) || node[0] !== "net") continue;
    const [, id, name] = node;
    if (node.length !== 3 || typeof id !== "string" || !/^\d+$/.test(id) || !Number.isSafeInteger(Number(id)) || !quoted(name) || declared.has(id) || names.has(name)) throw new Error("Malformed native net table");
    declared.add(id); names.add(name); nets.set(id, name);
  }
  return board.filter(node => Array.isArray(node) && ["segment", "arc", "via"].includes(String(node[0]))).map(node => {
    const item = node as Expression[];
    const fields = item.slice(1).filter(Array.isArray) as Expression[][];
    const netFields = fields.filter(field => field[0] === "net");
    if (netFields.length > 1) throw new Error("Ambiguous native copper ownership");
    const field = netFields[0];
    let net = '""';
    if (field) {
      const value = field[1];
      if (field.length !== 2 || typeof value !== "string") throw new Error("Malformed native copper ownership");
      if (quoted(value)) net = value;
      else {
        const name = nets.get(value);
        if (name === undefined) throw new Error("Unknown native copper net code");
        net = name;
      }
    }
    const geometry = fields.filter(field => ["start", "end", "mid", "at", "width", "size", "drill", "layer", "layers"].includes(String(field[0])))
      .map(field => JSON.stringify([(["segment", "arc"].includes(String(item[0])) && ["start", "end"].includes(String(field[0]))) ? "endpoint" : field[0], ...field.slice(1)])).sort();
    return JSON.stringify([item[0], net, geometry]);
  }).sort();
}

export function nativeCopperPreserved(submitted: string, saved: string): boolean {
  return JSON.stringify(nativeCopperInventory(submitted)) === JSON.stringify(nativeCopperInventory(saved));
}
