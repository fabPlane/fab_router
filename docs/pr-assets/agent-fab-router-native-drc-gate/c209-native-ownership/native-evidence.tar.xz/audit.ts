import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { nativeCopperInventory, nativeCopperPreserved } from '/home/hyper/bench/wt/fr-bugs/tools/kicad-board-rules.ts';
const root=import.meta.dir, corpus='/home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c206/full-after';
const rows=JSON.parse(await readFile(join(corpus,'results.json'),'utf8'));
const execute=promisify(execFile), results=[];
for (const row of rows) {
 const work=join(corpus,row.evidence,'work');
 const post=JSON.parse(await readFile(join(work,'native-thermal-postprocess/postprocess.json'),'utf8'));
 const run=join(root,'audit',`${row.case}-${row.seed}`);await mkdir(run,{recursive:true});
 const original=await readFile(join(work,'output.kicad_pcb'),'utf8');
 const board=join(run,'board.kicad_pcb');await writeFile(board,original);
 for (const ext of ['.kicad_pro','.kicad_dru']) {try {await writeFile(join(run,`board${ext}`),await readFile(join(work,`output${ext}`)));}catch(e){if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e;}}
 const report=join(run,'report.json');
 const log=await execute('kicad-cli',['pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',report,board],{timeout:120000,maxBuffer:4*1024*1024});
 await writeFile(join(run,'native.log'),log.stdout+log.stderr);
 const saved=await readFile(board,'utf8');
 const before=nativeCopperInventory(original),after=nativeCopperInventory(saved);
 const missing=[...before]; for(const key of after){const i=missing.indexOf(key);if(i>=0)missing.splice(i,1);}
 const added=[...after]; for(const key of before){const i=added.indexOf(key);if(i>=0)added.splice(i,1);}
 const result={case:row.case,seed:row.seed,priorApplied:post.applied,priorPassed:row.passed,preserved:nativeCopperPreserved(original,saved),missing,added};
 results.push(result);await writeFile(join(root,'audit-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(result));
}
