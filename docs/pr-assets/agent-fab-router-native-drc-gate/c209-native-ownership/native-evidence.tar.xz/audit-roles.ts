import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { nativeCopperPreserved } from '/home/hyper/bench/wt/fr-bugs/tools/kicad-board-rules.ts';
const root=import.meta.dir, corpus='/home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c206/full-after';
const rows=JSON.parse(await readFile(join(corpus,'results.json'),'utf8'));
const execute=promisify(execFile),results=[],seen=new Set<string>();
for(const row of rows) for(const role of ['input','routed']) {
 if(role==='input' && seen.has(row.case))continue;
 const source=join(corpus,row.evidence,`work/native-thermal-postprocess/search/${role}`);
 const dir=join(root,'audit-roles',`${row.case}-${row.seed}`,role);await mkdir(dir,{recursive:true});
 const submitted=await readFile(join(source,'board.kicad_pcb'),'utf8');await writeFile(join(dir,'submitted.kicad_pcb'),submitted);await writeFile(join(dir,'board.kicad_pcb'),submitted);
 for(const ext of ['.kicad_pro','.kicad_dru']) {try{await writeFile(join(dir,`board${ext}`),await readFile(join(source,`board${ext}`)));}catch(e){if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e;}}
 const log=await execute('kicad-cli',['pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',join(dir,'report.json'),join(dir,'board.kicad_pcb')],{timeout:120000,maxBuffer:4*1024*1024});await writeFile(join(dir,'native.log'),log.stdout+log.stderr);
 const preserved=nativeCopperPreserved(submitted,await readFile(join(dir,'board.kicad_pcb'),'utf8'));const result={case:row.case,seed:row.seed,role,preserved};results.push(result);console.log(JSON.stringify(result));await writeFile(join(root,'audit-roles-results.json'),JSON.stringify(results,null,2)+'\n');
 if(role==='input')seen.add(row.case);
}
