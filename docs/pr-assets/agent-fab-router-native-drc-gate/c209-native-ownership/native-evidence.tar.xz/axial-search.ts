import {searchNativeThermals} from '/home/hyper/bench/wt/fr-bugs/tools/native-thermal-search.ts';
import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';
const root=import.meta.dir;
const result=await searchNativeThermals(join(root,'axial/input.kicad_pcb'),join(root,'axial/routed.kicad_pcb'),join(root,'axial-search-accepted.json'),join(root,'axial-search'),1);
await writeFile(join(root,'axial-search-result.json'),JSON.stringify(result,null,2)+'\n');
if(result.published || result.repaired || result.attempts.length!==6 || result.attempts.some(a=>a.progress))throw new Error('Unsafe axial search must not publish');
console.log(JSON.stringify({published:result.published,attempts:result.attempts.length,opens:result.validation.opensAfter,errors:result.validation.newErrors.length}));
