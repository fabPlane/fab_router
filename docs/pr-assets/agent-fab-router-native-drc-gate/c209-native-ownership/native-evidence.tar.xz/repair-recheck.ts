import {searchNativeThermals} from '/home/hyper/bench/wt/fr-bugs/tools/native-thermal-search.ts';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
const root=import.meta.dir,corpus='/home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c206/full-after';
const rows=JSON.parse(await readFile(join(corpus,'results.json'),'utf8')),results=[];
for(const row of rows){
 if(!['qrpcard-qrpcard-j2-small','qrpcard-qrpcard-j4'].includes(row.case))continue;
 const original=join(corpus,row.evidence,'work/native-thermal-postprocess');
 const prior=JSON.parse(await readFile(join(original,'accepted.json'),'utf8'));
 const oldSearch=JSON.parse(await readFile(join(original,'search/result.json'),'utf8'));
 const dir=join(root,'repair-recheck',`${row.case}-${row.seed}`);await mkdir(dir,{recursive:true});
 const result=await searchNativeThermals(join(original,'search/input/board.kicad_pcb'),join(original,'search/routed/board.kicad_pcb'),join(dir,'accepted.json'),join(dir,'search'));
 const bundle=JSON.parse(await readFile(join(dir,'accepted.json'),'utf8'));
 const summary={case:row.case,seed:row.seed,published:result.published,repaired:result.repaired,oldAttempts:oldSearch.attempts.length,attempts:result.attempts.length,oldCandidateSha256:prior.validation.candidateSha256,candidateSha256:bundle.validation.candidateSha256,opens:result.validation.opensAfter,errors:result.validation.newErrors.length,lostSource:result.validation.lostTerminalPairs,lostRouted:result.validation.repair?.lostTerminalPairs};
 results.push(summary);await writeFile(join(root,'repair-recheck-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(summary));
 if(!result.published || summary.candidateSha256!==summary.oldCandidateSha256 || summary.attempts!==summary.oldAttempts)throw new Error('Existing complete-board repair changed');
}
if(results.length!==6)throw new Error('Expected six retained scored repairs');
