import {checkNativeRepair as after} from '/home/hyper/bench/wt/fr-bugs/tools/native-drc-gate.ts';
import {checkNativeRepair as before} from './before-tools/native-drc-gate.ts';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
const root=import.meta.dir,prior='/home/hyper/bench/agents/codex-fabpcb-bugs/scratch/c206/native-after-0';
const bundle=JSON.parse(await readFile(join(prior,'accepted.json'),'utf8'));
const dir=join(root,'axial');await mkdir(dir);
for(const role of ['input','routed','candidate']) for(const f of bundle[role]) await writeFile(join(dir,role+f.name.slice('board'.length)),Buffer.from(f.base64,'base64'));
for(const [phase,check] of [['before',before],['after',after]] as const)for(let repeat=0;repeat<3;repeat++){
 const result=await check(join(dir,'input.kicad_pcb'),join(dir,'routed.kicad_pcb'),join(dir,'candidate.kicad_pcb'));
 await writeFile(join(dir,`${phase}-${repeat}.json`),JSON.stringify(result,null,2)+'\n');console.log(phase,repeat,result.accepted,'nativeCopperChecks' in result?result.nativeCopperChecks:null);
}
