import sys,pathlib,gzip,copy,subprocess,json,shutil,importlib.util
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import sexpr as sx
FIX=pathlib.Path('test/fixtures/native-aquarius-thermal')
source=sx.parse(gzip.decompress((FIX/'input.kicad_pcb.gz').read_bytes()).decode())
full=sx.parse('(kicad_pcb '+(ROOT.parent/'c215/capacitor-via-up-0.1/added.sexpr').read_text()+')')[1:]
rows=[]
ids=['d86e9512-200c-46ad-83c9-170c84138a71','9dd50fff-11c6-4002-8144-cb40c29da824','f90f9c4d-2732-430a-99ed-443b9d6825eb','526748ae-cdba-488b-9c2f-37172461148a','6d6d8a51-847d-4cbf-b959-0d78d85dc73a']
for ident in ['pair','powerlocal','powerlocal-cap']:
 name='before' if ident is None else 'remove-'+ident
 excluded=set(ids[1:3] if ident=='pair' else ids[1:])
 if ident=='powerlocal-cap':excluded.add(ids[0])
 extras=[n for n in full if sx.uid(n) not in excluded]
 out=ROOT/name;out.mkdir();board=out/'board.kicad_pcb';board.write_text(sx.dump(source+extras)+'\n');(out/'added.sexpr').write_text('\n'.join(map(sx.dump,extras))+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());errors=[v for v in d['violations'] if v['severity']=='error'];r=dict(name=name,opens=len(d['unconnected_items']),errors=[v['type'] for v in errors],pads=[i['description'] for e in errors for i in e['items'] if 'Pad ' in i['description']]);rows.append(r);print(r,flush=True);(ROOT/'pair-results.json').write_text(json.dumps(rows,indent=2))
