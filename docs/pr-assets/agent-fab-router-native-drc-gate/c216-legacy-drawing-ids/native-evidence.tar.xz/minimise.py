import sys,pathlib,gzip,subprocess,json,shutil,math
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import sexpr as sx
FIX=pathlib.Path('test/fixtures/native-aquarius-thermal')
source=sx.parse(gzip.decompress((FIX/'input.kicad_pcb.gz').read_bytes()).decode())
full=sx.parse('(kicad_pcb '+(ROOT.parent/'c215/capacitor-via-up-0.1/added.sexpr').read_text()+')')[1:]
power=[n for n in full if sx.child(n,'net')[1]=='"+3V3"'];other=[n for n in full if n not in power]
rows=[];cache={}
def check(keep):
 key=tuple(sx.uid(n) for n in keep)
 if key in cache:return cache[key]
 out=ROOT/f'min-{len(rows):03}';out.mkdir();board=out/'board.kicad_pcb';extra=other+keep
 (out/'added.sexpr').write_text('\n'.join(map(sx.dump,extra))+'\n');board.write_text(sx.dump(source+extra)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());errors=[v for v in d['violations'] if v['severity']=='error'];has55=any(i['uuid']=='57ce983e-ec4e-48a5-9547-b23514d0d6a4' for e in errors if e['type']=='starved_thermal' for i in e['items'])
 r=dict(name=out.name,kept=list(key),has55=has55,opens=len(d['unconnected_items']),errors=[e['type'] for e in errors]);rows.append(r);cache[key]=has55;print(r,flush=True);(ROOT/'min-results.json').write_text(json.dumps(rows,indent=2));return has55
assert check(power);assert not check([])
keep=power[:];granularity=2
while len(keep)>=2:
 size=math.ceil(len(keep)/granularity);chunks=[keep[i:i+size] for i in range(0,len(keep),size)];reduced=False
 for chunk in chunks:
  complement=[n for n in keep if n not in chunk]
  if check(complement):keep=complement;granularity=max(2,granularity-1);reduced=True;break
 if reduced:continue
 if granularity>=len(keep):break
 granularity=min(len(keep),granularity*2)
(ROOT/'minimal-power.sexpr').write_text('\n'.join(map(sx.dump,keep))+'\n');print('MINIMAL',len(keep),[sx.uid(n) for n in keep],flush=True)
