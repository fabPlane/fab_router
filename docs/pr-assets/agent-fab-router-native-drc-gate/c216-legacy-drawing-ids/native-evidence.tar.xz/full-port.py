import pathlib,sys,json,gzip,copy,shutil
sys.dont_write_bytecode=True
r=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(r));import sexpr as sx
source=gzip.decompress((r/'fixture/input.kicad_pcb.gz').read_bytes()).decode();nodes=sx.parse(source);extras=sx.parse('(kicad_pcb '+(r.parent/'c215/capacitor-via-up-0.1/added.sexpr').read_text()+')')[1:]
old=sx.parse((r/'search-inputs/routed.kicad_pcb').read_text());prior={sx.uid(n) for n in old if isinstance(n,list)};repaired=sx.parse((r/'search-after/stage-0/101.kicad_pcb').read_text());added=[n for n in repaired if isinstance(n,list) and n[0]=='segment' and sx.uid(n) not in prior];assert len(added)==3
assert sum(sx.uid(n)=='6d6d8a51-847d-4cbf-b959-0d78d85dc73a' for n in extras)==1
candidate=[n for n in extras if sx.uid(n)!='6d6d8a51-847d-4cbf-b959-0d78d85dc73a']+added
out=r/'full-port';out.mkdir()
for name,items in [('input',[]),('routed',extras),('candidate',candidate)]:
 (out/(name+'.kicad_pcb')).write_text(sx.dump(nodes+items)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(r/'fixture'/('board'+ext),out/(name+ext))
(out/'delta.json').write_text(json.dumps(dict(removed=['6d6d8a51-847d-4cbf-b959-0d78d85dc73a'],added=[sx.uid(n) for n in added],before=len(extras),after=len(candidate)),indent=2)+'\n')
