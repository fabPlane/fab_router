import {resolve} from 'node:path';import {writeFile} from 'node:fs/promises';
const {checkNativeRepair}=await import(resolve('tools/native-drc-gate.ts'));
const r=process.argv[2]!;
const checked=await checkNativeRepair(r+'/input.kicad_pcb',r+'/routed.kicad_pcb',r+'/candidate.kicad_pcb');
await writeFile(r+'/check.json',JSON.stringify(checked,null,2));
console.log(JSON.stringify({errors:checked.newErrors.map(e=>e.type),lostSource:checked.lostTerminalPairs,opens:checked.opensAfter,lostCurrent:checked.repair?.lostTerminalPairs,relativeErrors:checked.repair?.newErrors,ownership:checked.nativeCopperChecks,accepted:checked.accepted,repairAccepted:checked.repair?.accepted},null,2));
