import sys,pathlib,gzip,subprocess,json,shutil,importlib.util
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));import sexpr as sx
FIX=pathlib.Path('test/fixtures/native-aquarius-thermal');source=sx.parse(gzip.decompress((FIX/'input.kicad_pcb.gz').read_bytes()).decode())
full=sx.parse('(kicad_pcb '+gzip.decompress((FIX/'full-added.sexpr.gz').read_bytes()).decode()+')')[1:];power=[n for n in full if sx.child(n,'net')[1]=='"+3V3"']
spec=importlib.util.spec_from_file_location('thermal',pathlib.Path('tools/native-thermal-proposals.py'));m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
rows=[]
for name,extra in [('power-before',power)]+[(f'power-55-{i}',m.parse(data.decode())[1:]) for i,data in enumerate(m.proposals(['kicad_pcb']+power,'526748ae-cdba-488b-9c2f-37172461148a',short=True))]:
 out=ROOT/name;out.mkdir();board=out/'board.kicad_pcb';(out/'added.sexpr').write_text('\n'.join(map(sx.dump,extra))+'\n');board.write_text(sx.dump(source+extra)+'\n')
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(FIX/('board'+ext),board.with_suffix(ext))
 p=subprocess.run(['timeout','120','kicad-cli','pcb','drc','--severity-all','--format','json','--units','mm','--refill-zones','--save-board','--output',str(out/'drc.json'),str(board)],capture_output=True,text=True,timeout=130);(out/'native.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 d=json.loads((out/'drc.json').read_text());errors=[v for v in d['violations'] if v['severity']=='error'];r=dict(name=name,opens=len(d['unconnected_items']),errors=[e['type'] for e in errors],pads=[i['description'] for e in errors for i in e['items'] if i['description'].startswith('Pad ')]);rows.append(r);print(r,flush=True);(ROOT/'detour-results.json').write_text(json.dumps(rows,indent=2))
