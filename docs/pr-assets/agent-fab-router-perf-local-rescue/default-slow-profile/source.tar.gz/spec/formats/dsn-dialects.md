# Observed DSN dialects

Every entry is *observed input* → *required interpretation* → *boards* (file names under
`spec/acceptance/boards/`). `F-nn` clauses are in `dsn.md`. Where the two reference
implementations disagree with each other or with the ruling, the observation and the ruling are
both recorded. "KiCad" below means the host recorded as `KiCad's Pcbnew` with the version in
`host_version`; four exporter families appear in the corpus: KiCad (4.0 … 10.99, about a hundred boards),
Eagle via a user-language script (3 boards), LibrePCB 2.0 (1 board), EasyEDA-style (7 boards:
two declare `EasyEDA Pro`, five carry no `parser` scope at all and share the same layout).

## Encoding, whole-file shape

- **D-1 Not a design file.** `Issue006-LPC18XX_43XX_SCH.dsn` is a binary OLE compound document
  (145 316 NUL bytes in 267 264). Required: `readDsn` returns `ok: false` with a `ParseError`
  (F-20) — the parse status is `parse-error`. Both references reject it.
- **D-2 Character encoding.** All 116 readable boards are valid UTF-8 without a byte-order
  mark; about a dozen contain non-ASCII text (Cyrillic, Chinese, German umlauts, `⌀`, `µ`). Required: F-1.
  Reference A reads the bytes as UTF-8 but its identifier scanner drops every character outside
  Windows-1252 from *bare* names read as identifiers: the bare image name
  `Предохранители:Цилиндр_5х20` becomes `:` and a bare `Соединители:PinSocket…` becomes
  `:PinSocket…`, while quoted names, bare layer names and bare net names survive intact;
  reference B reproduces this. Ruling: names are kept verbatim in every position (F-5, F-61,
  F-90). Boards: `Issue110-Pajalnaja_stancija.dsn` (bare Cyrillic layer names
  `Верхний_сигнальный` / `Нижний_сигнальный`, bare Cyrillic part numbers), `Issue110-Паяльная
  станция.dsn` (same content, Cyrillic file name), `Issue110-RelayModule.dsn` (bare and quoted
  Cyrillic image names, quoted Cyrillic part numbers), `Issue093-interf_u.dsn` (Chinese directory in the design
  name), `Issue199-StackOverflow-Signale_Vor+Block.dsn` (`Schaltpläne`), `Issue676-ch32v-tx118s.dsn` (`⌀` in image
  names), `Issue742-tastexx-pcb.dsn`, `Issue367-Charger.dsn`, `Issue297-myboard.dsn`,
  `Issue163-pic_programmer.dsn`, `Issue575-drc_Natural_Tone_Preamp_7_unconnected_items.dsn`.
- **D-3 Line endings and layout.** Files use LF only; KiCad indents with spaces and breaks
  long lists across lines; the EasyEDA-style files write `(rule(clear 0.605))` with no space
  after `(` and `(place u1 0 0 front 0\n      )`. Required: F-2 / F-3 (whitespace is never
  significant except as a separator; a scope head may directly follow `(`).
- **D-4 Design name.** KiCad writes the full export path as a quoted string with backslashes
  (`"F:\Spiwocoal\Documentos\…\Main ISO.dsn"`, `Issue035-ReadPlaceScope.dsn`) or forward slashes
  and spaces; Eagle writes `"untitled.brd"`; EasyEDA-style writes `''`, which with `"` as the
  quote character is the two-character bare name `''` (D-11); LibrePCB writes a bare name.
  Required: F-4 (backslashes are not escapes; `'` is ordinary), F-20.

## Numbers and identifiers

- **D-5 Resolutions and units seen.** `(resolution um 10) (unit um)`: all KiCad boards.
  `(resolution mil 2540) (unit mil)`: Eagle (`Issue143-rpi_splitter.dsn`,
  `Issue143-rpi_splitter_mod.dsn`, `Issue270-non-ansi_bracket.dsn`). `(resolution mm 1000000)
  (unit mm)`: LibrePCB (`Issue676-ch32v-tx118s.dsn`). `(resolution mil 1000)` with no `unit`:
  EasyEDA-style (`Issue070-Autorouter_FQ101_PCB_2022-05-13.dsn`,
  `Issue179-Autorouter_PCB1_2023-3-24.dsn`, `Issue289-Autorouter_PCB_FHT-8086_2024-03-08.dsn`,
  `Issue289-Autorouter_PCB_FHT-VGA_2024-03-25.dsn`, `Issue313-FastTest.dsn`,
  `Issue684-Autorouter_PCB1_2026-5-8.dsn`, `Issue721-Autorouter_CE2632_HarryMu_2026-6-15.dsn`).
  `(resolution um 10)` with no `unit`: `Issue187-processor.Z80.dsn`, `Issue191-processor.Z80-processor.Z80.dsn`.
  Required: F-40, F-41 (a missing `unit` means the resolution unit).
- **D-6 Keyword case.** `(PCB …` (upper case) opens Eagle, EasyEDA-style and router-written
  files (`Issue143-rpi_splitter.dsn`, `Issue070-Autorouter_FQ101_PCB_2022-05-13.dsn`,
  `Issue103-Board-Routed.dsn`); everything else is lower case. Required: F-10. Reference A
  accepts an irregular set of case variants (`Rect`, `VIA`, `Circle` but not every upper-case
  spelling); reference B accepts a slightly different set (`RECT` is a name to B and a keyword
  to A). Ruling: every head is case-insensitive.
- **D-7 Exponent numbers in value positions.** `(rotate 1e-07)` and `(rotate 2e-08)` on image
  pins (KiCad 6.0.9 / 7.0.5 exports of footprints with sub-microdegree pad rotations).
  Required: F-6 — the value is 10⁻⁷ / 2·10⁻⁸ degrees (F-91). Reference A's tokenizer splits
  `1e-07` into `1.0` and `7` because its exponent may not carry a leading zero, but the rotation
  is read through a separate number parser and comes out right; reference B reproduces both.
  Boards: `Issue157-TeamAdapt-LinePCB.dsn` (`1e-07`, 2 pins), `Issue214-router.dsn`
  (`2e-08`, 4 pins).
- **D-8 Names that lex as numbers.** Pin names `1` … `20` (every board), pin names `0e29`,
  `2e7`, `10e12`, `1221e15` and pin references `u1-1e31` (EasyEDA Pro: `Issue684-…`,
  `Issue721-…`), pin names `101e7` (`Issue179-Autorouter_PCB1_2023-3-24.dsn`), layer names `1`,
  `2`, `15`, `16` (all EasyEDA-style boards), net names `100`, `94` and `" 1"` (a quoted name
  with a leading space, `Issue753-CPU-85_r104.dsn`), image name `15pin:09561617712` and part
  number `(PN 09561617712)` (`Issue754-avionics_hub.dsn`), image pin `1.0`-style names in
  `Issue103-Board-Routed.dsn`. Required: F-7 — the name is the source text. Reference A reads
  names in a mode where a number is a string, so `0e29` survives; a bare `09561617712` survives
  too. Reference B reproduces this.
- **D-9 Bare punctuation as part numbers.** KiCad 5.1.2 writes single-character part numbers
  unquoted: `(PN \)`, `(PN ,)`, `(PN .)`, `(PN /)`, `(PN [)`, `(PN ])`, `(PN 7)`, `(PN 0.1u)`,
  `(PN nice!nano)`; `#` and names with spaces are quoted (`(PN "#")`, `(PN "Caps Lock")`).
  Required: F-5, F-7, F-81 — all 141 Parts of `Issue035-ReadPlaceScope.dsn` and all Parts of
  `Issue054-tairakb.dsn` read. Both references read all of them.
- **D-10 Identifier characters.** Bare names contain `-`, `.`, `/`, `:`, `#`, `$`, `@`, `!`,
  `+`, `~`, `{`, `}`, `[`, `]`, `,`, `\`, `'`, `=`, `;`: `/CM5/PCIE_PI.CLK_N`,
  `Capacitor_SMD:C_0603_1608Metric::1` (KiCad image names), `+3V3`, `+5V0-1` (net names),
  `1@1`, `W4F1-1@1` (pin names and pin references, `Issue015-StackOverflow.dsn`),
  `Round1$13.779528` (Eagle padstack), `~{WAIT}`, `~{BAI}` (KiCad 6+ active-low net names,
  bare, `Issue187-processor.Z80.dsn`), `/B_LCAS{slash}CAS0` (quoted, `Issue113-Protein.dsn`),
  `/~{SD_SS}` (quoted, `Issue155-CH376_MCP795_Module.dsn`), `1#Top` (quoted Eagle layer name).
  Required: F-5 — all are single bare or quoted lexemes; `{`, `}`, `|` and `` ` `` are ordinary
  characters. Reference A's tokenizer treats `{`, `}`, `|`, `` ` `` as characters to skip, which
  splits a bare word around them; net names are read through a different path in which they
  survive (`~{WAIT}` is a net in reference A's board). Ruling: ordinary characters everywhere.
- **D-11 Quote characters.** `"` is the declared quote character in every file that declares
  one (141 boards); no board declares `'` or `$`, so `"` is the quote character of every corpus
  board (F-4). `'` occurs (a) around names in EasyEDA-style files, which declare nothing or
  `"`: `(PCB ''` (`Issue070-…`, `Issue179-…`, `Issue289-…`, `Issue313-…`), `(class '' …)` and
  `(class $1N4396 '$1N4396' …)` (`Issue684-…`, `Issue721-…`); (b) *inside* bare names: pin
  names `A'`, `B'` and pin references `SW1-A'` (`Issue508-DAC2020_bm02.dsn`); (c) inside
  `"`-quoted strings: `"KiCad's Pcbnew"` (every KiCad board), `"2x20 pin 0.1'' female header"`
  (`Issue756-tomu-fpga.dsn`). Required: F-4 — `'` is an ordinary character in all three
  positions: the class names are `''` and `$1N4396`, the listed member `'$1N4396'` names no net
  (D-17), the design name of `(PCB ''` is `''`, and (b) and (c) read as they look.
  *References.* Both read net, class, class-member, layer and pin-reference names this way on
  every corpus board: the parse summaries of `Issue684-…` and `Issue721-…` record the NetGroup
  `''` and the net-named NetGroups with no members. Three departures were observed by running
  both full readers on synthetic designs: (1) the design name of `(pcb '' …)` — the D-16 boards
  included — comes back as the empty string, and an image or component name written `'IMG1'`
  as `IMG1`; (2) a declared `(string_quote ')` is recorded but not honoured — `(net 'Net A' …)`
  still reads as the net `'Net` with `A'` as the first member, while `(component 'IMG 1' …)`
  reads as `IMG 1`; (3) with `'` declared, `"NetA"` still reads as `NetA`. Their standalone
  tokenisers also read `'…'` as a string in every position (`dsn-tokens/quotes.jsonl` notes).
  Ruling Q-I1-29: one lexical rule everywhere, the published format's — only the declared
  character quotes; no corpus board is affected by the departures (none declares `'`, none
  writes an image or component name between apostrophes, and the design name of `(PCB ''` is
  not part of any acceptance output).
- **D-12 Non-ASCII bare names.** See D-2. Required: F-5.
- **D-13 Windows paths and backslashes.** Design names such as
  `"C:\Users\…\hw72nb.dsn"` (`Issue015-StackOverflow.dsn`, `Issue022-AutoRouter_interrupted.dsn`,
  `Issue034-Green14SegLED.dsn`, `Issue069-TestSensel-TestSensel.dsn`, …). Required: F-4 (no escapes).
- **D-14 `$` in names.** `ViaDefault$13.779528`, `Round1$13.779528` (Eagle padstacks),
  `$1N4396` (EasyEDA nets). Required: F-4 (`$` never quotes), F-5.

## Exporter families

- **D-15 Eagle (exported by a user-language script, host `CadSoft`).** Observed: `(host_cad CadSoft)`
  unquoted; `(case_sensitive off) (via_rotate_first on)` in `parser`; layers `"1#Top"`,
  `"16#Bottom"`; two boundaries — `(boundary (rect pcb 0 0 837.007874 1649.606299))` and
  `(boundary (path signal 0 …) (clearance_class boundary))`; six-decimal coordinates;
  `(control (via_at_smd on))`; `(rule (width 16.000000)(clearance 12.000000))` plus
  per-object-pair clearances `default_boundary`, `wire_via`, `pin_pin`, `pin_via`, `via_via`,
  `smd_pin`, `smd_via`, `smd_smd`, `area_wire`, …; `circ` as the circle head; `(flip_style
  rotate_first)` in the structure; quoted pin references `"J1"-"D+"`. Required: F-10 (aliases),
  F-62/F-63 (the `rect pcb` is the bounding rectangle, the `path signal` ring is the Rim, the
  Rim's Kind is `boundary`), F-72, F-74 (rotate-first placement), F-101, and
  `spec/rules/clearance.md` for the pair types. Boards: `Issue143-rpi_splitter.dsn`,
  `Issue143-rpi_splitter_mod.dsn`, `Issue270-non-ansi_bracket.dsn`.
- **D-16 EasyEDA-style (no `parser` scope, or `EasyEDA Pro`).** Observed: `(PCB ''` or
  `(PCB "PCB1"`; `(resolution mil 1000)` and no `unit`; `(boundary(path signal 0 …))` only —
  no `pcb` boundary; `(via via4 via0 …)`; `(grid via 0.25) (grid wire 0.25) (grid place 0.25)`;
  `(rule(clear 0.605))`, `(rule(clear 0.605 (type default_smd)))`, `(rule(clear 0.605 (type
  smd_smd)))`, `(rule(width 0.605))`; layers named `1`, `2` (and `15`, `16` in 4-layer files);
  one image `u1` holding every pad of the board as pins named like `887`, `0e29`; a single
  component `u1` placed at the origin; padstacks named `p887`, `p0e29`, `p38e5` with polygon
  shapes on layer `1` and aperture `0.01`; classes named by net (`(class $1N4396 '$1N4396' …)`)
  and one class named `''`. Required: F-33 (no parser scope is fine), F-63 (a
  `signal` path ring is the Rim), F-75 (grids ignored), F-10 (`clear`), F-7 (numeric layer and
  pin names), F-4 / D-11 (`'` is ordinary), F-102 (class named `''`). Boards: `Issue070-Autorouter_FQ101_PCB_2022-05-13.dsn`,
  `Issue179-Autorouter_PCB1_2023-3-24.dsn`, `Issue289-Autorouter_PCB_FHT-8086_2024-03-08.dsn`,
  `Issue289-Autorouter_PCB_FHT-VGA_2024-03-25.dsn`, `Issue313-FastTest.dsn`,
  `Issue684-Autorouter_PCB1_2026-5-8.dsn`, `Issue721-Autorouter_CE2632_HarryMu_2026-6-15.dsn`.
- **D-17 Class named `''` and members between apostrophes.** `(class '' (circuit (use_via
  via0)) (rule (width 15.75) (clearance 0.8)))` — with `"` as the quote character (D-11) this
  is a NetGroup named `''` (two apostrophes) that lists no nets; `(class $1N4396 '$1N4396' …)`
  is a NetGroup named `$1N4396` whose one listed member `'$1N4396'` names no net, so the net
  `$1N4396` stays in the default NetGroup and the group is empty. Required: F-4, F-102 (the
  groups are kept; they affect nothing unless a net names them; the parse summary lists them
  with no nets and every net in `default`). Both references read the boards this way. Boards:
  the EasyEDA Pro boards of D-16 (`Issue684-…`, `Issue721-…`).
- **D-18 LibrePCB 2.0.** Observed: `(pcb ch32v-tx118s` bare; `(resolution mm 1000000) (unit
  mm)`; every number with a decimal point (`0.0`, `21.59`); `(layer top_cu (type signal))`;
  `(boundary (path pcb 0.0 …))`; `(plane "GND" (polygon top_cu 0.0 …))`; a via named
  `"via-0.5:auto-1.0:auto-tht"`; `(clearance 0.0 (type smd_via_same_net))` and
  `via_via_same_net`; components named `"J3:Soldered Wire Connector 1x01 ⌀1.0mm"`; a component
  `BOARD` with an image of no pins; `(place "C1" 19.685 10.795 front 270.0)` with a real
  rotation; padstacks whose names contain `:` and `-` but no `_` before the `:` (so no drill can
  be inferred from the name, `padstack-names.md`). Required: F-6 (`0.0` is 0), F-80 (rotation
  `270.0`), F-91, `padstack-names.md` P-10. Board: `Issue676-ch32v-tx118s.dsn`.
- **D-19 `unit` handling.** See D-5. The references ignore the `unit` scope and interpret every
  number in the resolution unit; the specification honours `unit` (F-41). In the corpus the two
  never differ, so no board distinguishes the readings.
- **D-20 Router-written design files.** Files exported by a router rather than by a CAD tool:
  `(PCB "ERISC 4"`, a `parser` with `(generated_by_…)`, `(structure … (snap_angle
  fortyfive_degree) (control (via_at_smd off)) (autoroute_settings …))`, both a `pcb` and a
  `signal` boundary, `(via "Via[0-1]_600:300_um" "Via[0-1]_600:300_um")` with a repeated name,
  `(clearance 200.0 (type kicad))` (a clearance type naming a class that does not exist),
  images with `(side front)`, net scopes with an explicit subnet number `(net "/datEx16" 1 …)`,
  classes with `(circuit (use_layer F.Cu B.Cu))` and `(via_rule …)`, wiring written as
  `polyline_path` with `(clearance_class "kicad_default")` and `(type shove_fixed)`. Required:
  F-54 (polyline corners), F-69 (duplicate via names de-duplicated), F-73, F-100, F-112
  (`shove_fixed` is `free`), and `spec/rules/clearance.md` for a `type` that names no class.
  Boards: `Issue103-Board-Routed.dsn`, `Issue187-processor.Z80.dsn`, `Issue191-processor.Z80-processor.Z80.dsn`,
  `Issue413-test.dsn`.

## Structure quirks

- **D-21 Keepouts on the `pcb` pseudo-layer.** No corpus board has one (all corpus keepouts are
  on `signal` — 67 boards — or on a named layer). Both references reject a `pcb`-layer keepout
  (the board fails to read). Ruling: F-66, a `pcb` keepout is a Fence on every Sheet, because
  that is what the DLR's reserved layer name means and refusing the whole board is the worse
  failure.
- **D-22 `signal`-pseudo-layer shapes.** Keepouts `(keepout "" (polygon signal 0 …))` (KiCad
  zones with "no tracks" on all copper layers; `Issue015-StackOverflow.dsn`,
  `Issue178-KeebMaker_Sofle_Choc.dsn` with 59 of them), boundaries `(path signal 0 …)`
  (D-15, D-16), image outlines `(outline (path signal 120 …))` (every KiCad board),
  `(clearance … (type …))` lists are unrelated. Required: F-66 (one Fence per signal Sheet),
  F-63, F-92. Image dedup note: both references merge images (see D-23).
- **D-23 Image variants `::N` and same-named images.** KiCad writes one image per distinct pad
  set and suffixes variants: `Capacitor_SMD:C_0603_1608Metric` and
  `Capacitor_SMD:C_0603_1608Metric::1` (`Issue015-StackOverflow.dsn`), up to `::56`
  (`Issue178-KeebMaker_Sofle_Choc.dsn`). Two images may differ only by a pad offset of 0.001
  file units (`easyeda2kicad:LED-SMD_6P-L5.0-W5.0-TL` and `…::1`, `Issue297-myboard.dsn`).
  Required: F-90 — names verbatim, no merging; a Part's package is the image the file named.
  Reference A strips the suffix, merges an image into an earlier one when every pin coincides
  after rounding to its grid, and re-numbers the rest from `::1` in order of appearance;
  reference B does the same with a different tie-break, so the two disagree on which Parts
  belong to which `::N` package on 14 boards (`Issue066-Project_GP8B.dsn`,
  `Issue102-Mars-64-revE-rot00.dsn`, `Issue153-wavefolder.dsn`, `Issue283-UnconnectedTracesUnderPads-Natural_Tone_Preamp.dsn`, …).
  Ruling: no merging; the session's `placement` therefore names the file's image (`ses.md`
  F-S32).
- **D-24 Degenerate keepout.** `(keepout "" (polygon signal 0 19220 -19695 19220 -19695 19220
  -19695))` — three identical vertices (KiCad 4.0.7). Required: F-67 — skipped with a
  diagnostic, the board reads and routes. Both references skip it. Board:
  `Issue229-display-8-digit-hc595.dsn`.
- **D-25 Degenerate padstack shape.** No corpus board defines one; reference A enlarges a
  zero-area pad shape by one LU with a warning. Ruling: F-96 (dropped with a diagnostic).
- **D-26 Concave pad polygons.** KiCad `Cust[T]Pad_…` custom pads and `RoundRect[T]Pad_…`
  polygon approximations (`Issue034-Green14SegLED.dsn`, `Issue039-bug-design.dsn`,
  `Issue508-DAC2020_bm06.dsn`; 99 boards carry polygon pad shapes, most convex). Reference A
  routes and checks against the convex hull of a concave pad polygon. Ruling: F-98 — the exact
  polygon is the copper; a router may use the hull for its own clearance queries.
- **D-27 Empty net name in a class list.** KiCad 8.0.0 … 10.x write `(class kicad_default ""
  GND …)`: the first net of the default class is the empty string (the "no net"). Required:
  F-102 — the `""` entry is ignored. Reference A drops an empty *first* entry and would stop the
  list at a later one; reference B reproduces this. Ruling: ignored wherever it occurs.
  Boards: `Issue269-z10_module.dsn`, `Issue297-myboard.dsn`, `Issue269-min_fr_test-min_fr_test.dsn` (and
  `Issue269-min_fr_test-min_fr_test_no_quotes.dsn`, the same board with the `""` removed — both must read to the same
  Layout).
- **D-28 Duplicate padstack definitions.** KiCad 5 writes the same custom-pad name twice with
  different polygons (`Cust[T]Pad_1000x500_1000x_1500_23_um` in `Issue034-Green14SegLED.dsn`,
  `Issue039-bug-design.dsn`, `Issue102-Mars-64-revE-rot00.dsn`, `Issue145-smoothieboard.dsn`,
  `Issue326-Mars-64-revE.dsn`) and two via definitions whose names differ only in decimals
  (`Via[0-1]_1541.78:1186.18_um` and `Via[0-1]_1541.8:1186.18_um`, `Issue015-StackOverflow.dsn`,
  `Issue022-AutoRouter_interrupted.dsn`); KiCad 7 writes `RoundRect[A][600,0]Pad_2600x1600_401.522_um_0.000000_0`
  and `…2600x1600.2_401.572_um_0.000000_0` (`Issue209-split05.dsn`, `Issue209-split10.dsn`),
  which normalise to one name. Required: F-97 and `padstack-names.md` P-5 — the first
  definition wins. Both references keep the first.
- **D-29 Keepout without a name.** `(keepout (polygon F.Cu 0 …))` — the shape directly after the
  head. Required: F-66 (the name is optional). Boards: `Issue413-test.dsn`,
  `Issue754-avionics_hub.dsn` (`wire_keepout ""` on a signal layer named `Ground`),
  `Issue039-bug-design.dsn` and `Issue732-RoyalBlue54L-Feather.dsn` (`via_keepout ""`).
- **D-30 Planes on signal layers and `power` layers.** KiCad exports every filled zone as
  `(plane NET (polygon LAYER 0 …))` on signal layers (`Issue367-Charger.dsn` has 22,
  `Issue732-CM5_MINIMA_3.dsn` 18); ten boards declare `(type power)` layers
  (`Issue145-smoothieboard.dsn`, `Issue230-CNH_Functional_Tester_1.dsn`,
  `Issue269-NoViasOnPowerPlanes-Issue269-NoViasOnPowerPlanes.dsn`, `Issue269-caniot-tiny-arm.dsn`, `Issue269-z10_module.dsn`,
  `Issue555-CNH_Functional_Tester_1.dsn`, `Issue733-kicad_complex_hierarchy_input_design.dsn`,
  `Issue753-CPU-85_r104.dsn`), some of them with `(use_net …)` and no plane shape. Required:
  F-60, F-68 and `spec/rules/layers.md` (which also records the references' "large pour on an
  inner layer with no wires makes that layer a plane" behaviour).
- **D-31 Wiring polygons with windows.** KiCad 10.99 development builds write filled zones in
  `wiring` as `(wire (polygon F.Cu 0 …)(net +3V3)(type protect) (window (polygon F.Cu 0 …)))`
  (`Issue756-tomu-fpga7.dsn`, `Issue756-tomu-fpga8.dsn`, `Issue756-tomu-fpga9.dsn`; 13–14 per
  board). Required: F-110 (a Pour with holes, Hold `held`), `ses.md` F-S42 (written back as a
  polygon wire without `type`).
- **D-32 Collinear micro-wires.** `Issue723-CombineStackOverflow.dsn` (hand-made) has 4 000
  collinear 200 µm `GND` wires end to end on one Sheet. Required: F-110 — 4 000 Tracks are read;
  whether a router merges collinear same-net Tracks is its own business (`ses.md` F-S50 makes
  the session comparison insensitive to it). Both references merge them while reading (their
  boards hold a single Track); the Layout as read holds 4 000.
- **D-33 Locked (`fix`) wiring only.** `Issue753-CPU-85_r104.dsn` carries 65 wires and 19 vias
  all `(type fix)`. Required: F-112 (`locked`), `ses.md` F-S43 (not written back).
- **D-34 Wire types across KiCad versions.** KiCad 4/5 write `(type protect)` on every track;
  KiCad 6+ write `(type route)`; locked tracks are `(type fix)`
  (`Issue230-CNH_Functional_Tester_1.dsn`: 8 `fix` wires). Required: F-112.
- **D-35 Pin references with hyphens in names.** `B1--`, `U18--`, `U19--` (pin named `-`),
  `SW1-A'`, `X4-MT1`, `"FP-Altair1"-1` (component name containing `-`, quoted),
  `"J1"-"D+"`, `"J3-"-"D+"`, `"J2(--)"-"GND"`, `"J1 + - ( )"-"GND"`, `"J3 -+"-"_VBUS #22"`,
  `J2-VBUS "J1"-VBUS`. Required: F-101. Boards: `Issue508-DAC2020_bm02.dsn`,
  `Issue270-non-ansi_bracket.dsn`, `Issue753-CPU-85_r104.dsn`, `Issue143-rpi_splitter.dsn`,
  `Issue143-rpi_splitter_mod.dsn` (a hand-edited stress file whose odd component names do not
  exist: those entries are `pin-unknown` and the board still reads).
- **D-36 Old KiCad quirks.** KiCad 4.0.1 / 4.0.7 exports: stray quotes in part numbers
  (F-14, `Issue229-display-8-digit-hc595.dsn`), the degenerate keepout of D-24, and via padstack
  names with decimals (`Via[0-1]_1016:485.7_um`). Required: read as the clauses say; the
  references additionally log a warning recommending a newer KiCad — no observable effect.
- **D-37 Empty `host_version`.** `(host_version "")` (`Issue420-contribution-board.dsn`,
  `Issue433-my-board.dsn`). Required: F-32 (an empty string); the session writes it back as
  `(host_version "")` (`ses.md` F-S31 — reference A writes `(host_version )`, reference B
  `(host_version "")`; ruling: B).
- **D-39 Wires that double back.** KiCad 5 exports contain a few wires whose path returns to an
  earlier vertex (`A → B → A`): 3 in `Issue022-AutoRouter_interrupted.dsn`, 2 in
  `Issue575-drc_Natural_Tone_Preamp_7_unconnected_items.dsn`. Required: F-110 — each is one
  Track with two overlapping legs (724 and 1 346 Tracks respectively). Both references drop
  such wires while normalising (721 and 1 344). The same boards carry a handful of wires that
  repeat an earlier wire exactly; those are Tracks too.
- **D-38 Padstack names with decimals.** Every KiCad board: `RoundRect[T]Pad_875x950_219.582_um`,
  `Round[A]Pad_1320.800000_um`, `Via[0-1]_685.8:330.2_um`,
  `RoundRect[T]Pad_3199.9935999999993x1599.9967999999997_um` (`Issue420-contribution-board.dsn`).
  Required: `padstack-names.md`.

## From S2

Each entry: *observed input* → *required interpretation* → *boards where it occurs* → *what the
two references did and why the ruling was made*. The parse summary of every board listed records
the ruling in its `notes`.

### D-S2-01 — a `plane` scope makes its net a plane net

*Observed input.* `(plane GND (polygon B.Cu 0 …))` inside `structure`, on a board whose layers are
all `(type signal)`; or a `(layer X (type power) (use_net N))` layer.

*Required interpretation.* The net named by a `plane` scope, or by a power layer's `use_net`
list, is a **plane net** (`nets[].plane: true` in the parse summary; `spec/rules/layers.md`
L-06). The Pour itself is inserted on the named Sheet, locked (`hold: "locked"`), owned by that
net.
A net named only by a `plane` scope and by no `net` scope is still created (with zero Pads).

*Boards.* 34 boards, e.g. `Issue015-StackOverflow.dsn` (GND), `Issue367-Charger.dsn` (9 nets),
`cm5-carrier.dsn` (4 nets), `Issue230-CNH_Functional_Tester_1.dsn` (GND, on two power layers),
`Issue756-tomu-fpga.dsn` (6 nets).

*References.* Reference A marks the net as a plane net whenever a `plane` scope names it;
reference B marks only nets listed by a power layer's `use_net`, so it marks none of the 34
boards' nets. Ruling: A — the SPECCTRA reference defines `plane` as "a power plane for the named
net" (Design Language Reference, `structure` / `plane`), and the flag is what turns on the
plane-via cost and the "reached the Pour, done" completion rule (`spec/rules/connectivity.md`
K-07); the set of plane nets is exactly the set of nets named by `plane` scopes or power-layer
`use_net` lists on every corpus board, so no area heuristic is needed.

### D-S2-02 — via padstack list without repeats

*Observed input.* The structure `(via "V1" "V2")` list plus every class's `(circuit (use_via V1))`
plus network `(via …)` definitions naming the same padstacks.

*Required interpretation.* `viaPadstacks[]` is the ordered union in first-mention order — the
structure list first, then each class's `use_via` names in file order, then padstacks named only
by network `via` definitions — with every repeated name dropped.

*Boards.* 136 of the 149 board files (every KiCad export with a `use_via` list), e.g. `Issue026-J2_reference.dsn`
(listed twice by reference A, once in the ruling).

*References.* Reference A concatenates the lists and keeps repeats; reference B keeps distinct
names. Ruling: B — repeats carry no information, and Barrel candidates are chosen per via rule,
never from this list directly.

### D-S2-03 — the via rule made from a class's `use_via` is named after the class as written

*Observed input.* `(class kicad_default … (circuit (use_via "Via[0-1]_800:400_um")))` with no
`via_rule` scope in the file.

*Required interpretation.* Reading such a class creates a via rule named `kicad_default` (the
class name as written) holding the listed padstacks in list order, and assigns it to the default
NetGroup (`kicad_default` *is* the default group, `spec/rules/nets.md` N-05). The rule created
when the file has no `via_rule` scope at all is named `default` and is created first
(`spec/rules/vias.md` V-03).

*Boards.* 126 of the 149 board files — every KiCad export.

*References.* Reference A names the class-derived rule `default` (because it has already merged
the class into the default group); reference B keeps `kicad_default`. Ruling: B — the name is
then the one the file uses, and the two rules stay distinguishable in the summary.

### D-S2-04 — `use_via` names with fractional dimensions resolve like the structure `via` list

*Observed input.* `(padstack "Via[0-1]_685.8:330.2_um" …)` in the library and
`(circuit (use_via Via[0-1]_685.8:330.2_um))` in a class.

*Required interpretation.* Padstack references in `use_via` lists are normalised with the same
rule as padstack definition names and the structure `via` list (`spec/formats/padstack-names.md`):
the fractional parts are dropped, so the reference resolves to the PadForm `Via[0-1]_685:330_um`
and the class's via rule contains it. A `use_via` name that resolves to no PadForm is skipped
with a diagnostic; if that leaves the rule empty the NetGroup has no Barrel candidates.

*Boards.* 13 boards: `Issue015-StackOverflow.dsn` (6 class rules), `Issue022-AutoRouter_interrupted.dsn`,
`Issue027-zMRETestFixture.dsn`, `Issue029-hw48na.dsn`, `Issue208-router.dsn`,
`Issue230-CNH_Functional_Tester_1.dsn` (and its copy `Issue230-CNH_Functional_Tester-CNH_Functional_Tester_1.dsn`), `Issue555-CNH_Functional_Tester_1.dsn`,
`Issue756-tomu-fpga.dsn`, `-fpga7`, `-fpga8`, `-fpga9`, `-fpga11`.

*References.* Reference A normalises the structure `via` list but compares `use_via` names
verbatim, leaving those class via rules empty (the nets of such a class then route without
Barrels); reference B normalises both. Ruling: B — the file plainly names the padstack it
defined; an empty rule would silently forbid vias for the whole class.

### D-S2-05 — `image` names with a `::n` suffix are kept as written

*Observed input.* `(image Capacitor_SMD:C_0805_2012Metric …)` and
`(image Capacitor_SMD:C_0805_2012Metric::1 …)` — the exporter writes a second image with a `::n`
suffix when a footprint is used with different pad variants; the two may or may not have
identical pins. `(component Capacitor_SMD:C_0805_2012Metric::1 (place C3 …))` refers to the
suffixed image.

*Required interpretation.* Both images are PadForm/pin definitions in their own right and a
Part's `package` is the name exactly as its `component` scope writes it (`components[].package`
in the parse summary). Pin resolution uses the named image; a component naming an image that does
not exist but whose base name (suffix removed) does exist uses the base image.

*Boards.* 67 boards place at least one Part through a `::n` image — 2 028 Parts in all, from 1
(`Issue054-tairakb.dsn`) to 200 (`Issue178-KeebMaker_Sofle_Choc.dsn`); the references report
1 717 of them (on 60 boards) by a merged name; the parse summaries record every one of them as
written (rulings Q-I1-27/Q-I1-28).

*References.* Both references merge a suffixed image into an earlier image whose pins coincide
and report the earlier image's name for the Parts placed through it, re-numbering the rest
(D-23; they disagree with each other only on the tie-break). Ruling: names as written — no
geometry differs either way, and the file's own name is the one a session writer or a diagnostic
should echo.
