"""Verify full source snapshots and every retained routing attempt; run after extraction."""
from pathlib import Path
import hashlib,json,subprocess,sys
w=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((w/'source-audit.json').read_text());a=audit['files']
assert {k for k in a['original'].keys()|a['candidate'].keys()if a['original'].get(k)!=a['candidate'].get(k)}=={'src/geom/onboard.ts'}
for mode in a:
 for name,h in a[mode].items():assert sha(w/'replay'/mode/name)==h,(mode,name)
for name in ['records','aquarius-records']:
 rows=json.loads((w/'replay'/f'{name}.json').read_text())
 assert {(r['pair'],r['mode'])for r in rows}=={(i,m)for i in range(1,4)for m in ['original','candidate']}
 if name=='aquarius-records':
  for r in rows:
   raw=json.loads((w/'replay'/f"aquarius-{r['pair']}-{r['mode']}.jsonl").read_text())
   assert raw=={k:v for k,v in r.items()if k not in ['pair','mode']}
   assert raw['input_sha256']==sha(w/'replay/aquarius-input/board.dsn')
   assert raw['ses_sha256']==sha(w/'aquarius-reference.ses')
subprocess.run([sys.executable,w/'replay/summarize.py'],check=True)
print('PASS complete source hashes, twelve attempts, sessions, statistics, settings, reports and diagnostic logs')
