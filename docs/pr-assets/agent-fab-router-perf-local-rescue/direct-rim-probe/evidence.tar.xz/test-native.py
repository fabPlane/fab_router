from pathlib import Path
import subprocess,sys,json
w=Path(__file__).resolve().parent
rows=json.loads((w/'native-candidate/results.json').read_text());row=rows[0]
def reject(p,mutate,label):
 old=p.read_bytes()
 try:
  p.write_bytes(mutate(old))
  r=subprocess.run([sys.executable,w/'check-native.py'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  assert r.returncode!=0,label
 finally:p.write_bytes(old)
def opens(b):
 x=json.loads(b);x[0]['opens']+=1;return json.dumps(x).encode()
reject(w/'native-candidate/results.json',opens,'native open count')
reject(w/'native-candidate'/row['evidence']/'work/board.ses',lambda b:b+b'\n','native SES')
subprocess.run([sys.executable,w/'check-native.py'],check=True)
print('PASS deliberate native open-count/session corruption rejected')
