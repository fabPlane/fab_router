from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for mode in ['original','candidate']:
 p=w/'replay'/mode
 for args in [['init','-q','-b','agent/fab-router-perf-probe-capture'],['add','src','spec','test','tools','package.json','tsconfig.json','docs'],['-c','user.name=Benchmark Agent','-c','user.email=benchmark-agent@users.noreply.github.com','commit','-qm','Capture direct rim probe experiment']]:subprocess.run(['git','-C',str(p),*args],check=True)
