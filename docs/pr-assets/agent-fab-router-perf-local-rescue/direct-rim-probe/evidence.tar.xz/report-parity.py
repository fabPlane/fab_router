from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent
rows=[json.loads((w/f'native-{m}/results.json').read_text())for m in ['original','candidate']]
by=[{(r['case'],r['seed']):r for r in rs}for rs in rows]
assert len(by[0])==len(by[1])==78
for k in by[0]:
 results=[]
 for mode,rs in zip(['original','candidate'],by):
  d=w/f'native-{mode}'/rs[k]['evidence']/'work'
  x=json.loads((d/'router-summary.json').read_text())['result'];x['report'].pop('wallClockMs',None)
  results.append(x)
 assert results[0]==results[1],k
print('PASS all 78 full engine reports/statistics match except wallClockMs')
