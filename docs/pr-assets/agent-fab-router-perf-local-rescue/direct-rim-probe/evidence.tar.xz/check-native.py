"""Recompute full native comparison and demand exact paired output/quality preservation."""
from pathlib import Path
import json,subprocess,sys,tempfile
w=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='native-check-',dir=w) as tmp:
 p=Path(tmp)/'comparison.json'
 subprocess.run([sys.executable,w/'compare.py',w/'native-original',w/'native-candidate',p],check=True,stdout=subprocess.DEVNULL)
 x=json.loads(p.read_text());assert x['same_sessions']==78 and not x['regressions']
 assert x==json.loads((w/'comparison.json').read_text())
subprocess.run([sys.executable,w/'report-parity.py'],check=True)
print('PASS all 156 native attempts, frozen controls, paired inputs, settings, sessions and outcomes')
