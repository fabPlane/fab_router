from pathlib import Path
import hashlib,json
w=Path(__file__).resolve().parent/'replay'
(w/'candidate/src/lattice/grid.ts').write_bytes((w/'original/src/lattice/grid.ts').read_bytes())
p=w/'candidate/src/geom/onboard.ts'
s=p.read_text(); old='''  const core = coreOf(part);
  const count = core.r > 0 ? Math.min(1, core.pts.length) : core.pts.length;
  for (let i = 0; i < count; i++) {
    const p = core.pts[i]!;
    if (rim.outline.length >= 3 && pointInRing(rim.outline, p) === "outside") return false;
    for (const c of rim.cutouts) if (c.length >= 3 && pointInRing(c, p) === "inside") return false;
  }
  return true;
}'''
new='''  // Positive-radius shapes need only the first core point. Read it directly,
  // avoiding the temporary core and point array for disks and capsules.
  if (part.kind === "disk" && part.r > 0) return pointWithinRim(rim, part.c);
  if (part.kind === "capsule" && part.r > 0) return pointWithinRim(rim, part.a);
  if (part.kind === "rounded" && part.r > 0) {
    return part.pts.length === 0 || pointWithinRim(rim, part.pts[0]!);
  }
  const core = coreOf(part);
  for (const p of core.pts) if (!pointWithinRim(rim, p)) return false;
  return true;
}

function pointWithinRim(rim: Rim, p: Pt): boolean {
  if (rim.outline.length >= 3 && pointInRing(rim.outline, p) === "outside") return false;
  for (const c of rim.cutouts) if (c.length >= 3 && pointInRing(c, p) === "inside") return false;
  return true;
}'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
(w.parent/'candidate-onboard.ts').write_bytes(p.read_bytes())
print(hashlib.sha256(p.read_bytes()).hexdigest())
