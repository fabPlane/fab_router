from pathlib import Path
import hashlib,json,subprocess
w=Path(__file__).resolve().parent/'replay'
audit={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{}}
for mode in ['original','candidate']:
 audit['files'][mode]={str(p.relative_to(w/mode)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((w/mode).rglob('*')) if p.is_file() and 'node_modules' not in p.parts}
a=audit['files'];changed=[k for k in a['original'].keys()|a['candidate'].keys()if a['original'].get(k)!=a['candidate'].get(k)]
assert changed==['src/geom/onboard.ts'],changed
audit['modified']=changed
(w.parent/'source-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('PASS complete staged file hashes; sole delta:',changed)
