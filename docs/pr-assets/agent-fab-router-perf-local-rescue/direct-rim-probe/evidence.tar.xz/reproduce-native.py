"""From extracted archive: python3 reproduce-native.py ENGINE_REPO BENCH_CHECKOUT NEW_OUT"""
from pathlib import Path
import shutil,subprocess,sys
w=Path(__file__).resolve().parent
repo,bench,out=map(lambda s:Path(s).resolve(),sys.argv[1:]);out.mkdir(exist_ok=False)
for mode in ['original','candidate']:
 p=out/'replay'/mode
 shutil.copytree(w/'replay'/mode,p,ignore=shutil.ignore_patterns('.git','node_modules'))
 (p/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for n in ['prepare-native.py','native.py','compare.py','report-parity.py']:
 s=(w/n).read_text().replace("cwd='/home/hyper/bench/wt/fp-perf'",'cwd='+repr(str(bench)))
 (out/n).write_text(s)
subprocess.run([sys.executable,out/'prepare-native.py'],check=True)
subprocess.run([sys.executable,out/'native.py'],check=True)
subprocess.run([sys.executable,out/'report-parity.py'],check=True)
