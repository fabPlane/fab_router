from pathlib import Path
import subprocess,json,hashlib,time
w=Path(__file__).resolve().parent
work=w/'aquarius-input'
records=[]
for pair in range(1,4):
 for mode in (['candidate','original']if pair%2 else ['original','candidate']):
  name=f'aquarius-{pair}-{mode}'
  with (w/f'{name}.jsonl').open('w')as out,(w/f'{name}.log').open('w')as err:
   r=subprocess.run(['taskset','-c','12-19','nice','-n','10','timeout','--kill-after=5','300','bun',w/'replay.ts',w/mode,work,'1'],stdout=out,stderr=err)
  assert r.returncode==0,(name,r.returncode)
  x=json.loads((w/f'{name}.jsonl').read_text());records.append({'pair':pair,'mode':mode,**x})
  (w/'aquarius-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,x['seconds'],flush=True)
