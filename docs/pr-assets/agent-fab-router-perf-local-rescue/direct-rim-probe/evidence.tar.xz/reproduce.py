"""Replay isolated sources from an extracted evidence archive: python3 reproduce.py REPO NEW_OUT"""
from pathlib import Path
import shutil,subprocess,sys
w=Path(__file__).resolve().parent
repo,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=False)
for mode in ['original','candidate']:
 shutil.copytree(w/'replay'/mode,out/mode)
 (out/mode/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
for n in ['stress.ts','replay.ts','summarize.py','run.py','aquarius.py','l2.dsn']:
 shutil.copyfile(w/'replay'/n,out/n)
shutil.copytree(w/'replay/aquarius-input',out/'aquarius-input')
for script in ['run.py','aquarius.py']:
 subprocess.run(['taskset','-c','12-19','nice','-n','10','timeout','--kill-after=10','1200',sys.executable,out/script],check=True)
subprocess.run([sys.executable,out/'summarize.py'],check=True)
