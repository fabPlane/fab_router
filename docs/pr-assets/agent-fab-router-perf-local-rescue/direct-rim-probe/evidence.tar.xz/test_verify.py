"""Verifier must reject changed session bytes, report completion and recovery net id."""
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
checks=[]
def reject(path,mutate,label):
 old=path.read_bytes()
 try:
  path.write_bytes(mutate(old))
  r=subprocess.run([sys.executable,w/'verify.py'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  assert r.returncode!=0,label
  checks.append(label)
 finally:path.write_bytes(old)
reject(w/'replay/1-candidate/board.ses',lambda b:b+b'\n','session bytes')
def change_report(b):
 x=json.loads(b);x['report']['incomplete']=['deliberately corrupted'];return json.dumps(x).encode()
reject(w/'replay/1-candidate/result.json',change_report,'report')
def change_log(b):
 x=json.loads(b)
 row=next(r for r in x if r['mode']=='candidate')
 i=next(i for i,s in enumerate(row['logs'])if s.startswith('local-recovery result '))
 v=json.loads(row['logs'][i][len('local-recovery result '):]);v['net']='deliberately corrupted'
 row['logs'][i]='local-recovery result '+json.dumps(v)
 return json.dumps(x).encode()
# Keep duplicate raw metadata consistent so normalization itself must catch the net mutation.
meta=w/'replay/aquarius-records.json'
raw=w/'replay/aquarius-1-candidate.jsonl'
oldmeta,oldraw=meta.read_bytes(),raw.read_bytes()
try:
 changed=change_log(oldmeta)
 rows=json.loads(changed);row=next(r for r in rows if r['mode']=='candidate')
 meta.write_bytes(changed)
 raw.write_text(json.dumps({k:v for k,v in row.items()if k not in ['pair','mode']}))
 r=subprocess.run([sys.executable,w/'verify.py'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 assert r.returncode!=0,'recovery net with consistent metadata'
 checks.append('recovery net with consistent metadata')
finally:
 meta.write_bytes(oldmeta);raw.write_bytes(oldraw)
subprocess.run([sys.executable,w/'verify.py'],check=True,stdout=subprocess.DEVNULL)
print('PASS mutation controls:',', '.join(checks))
